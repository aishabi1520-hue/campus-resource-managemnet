// Asks for confirmation before submitting any form that has a data-confirm attribute
// (cancel booking, delete resource). Kept in its own file so no inline JavaScript is needed.
document.addEventListener('submit', function (event) {
  var message = event.target.getAttribute('data-confirm');
  if (message && !window.confirm(message)) {
    event.preventDefault();
  }
});
