Put the MySQL JDBC driver (Connector/J) jar in this folder.

1. Open  https://dev.mysql.com/downloads/connector/j/
2. Choose "Platform Independent" and download the ZIP.
3. Unzip it and copy  mysql-connector-j-<version>.jar  into this lib/ folder.

The class name used in config/db.properties (com.mysql.cj.jdbc.Driver) is the same
for every Connector/J 8.x and 9.x version.
