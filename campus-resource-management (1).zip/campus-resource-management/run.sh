#!/usr/bin/env bash
# Compile and start the Campus Resource Management System (Linux / macOS / Git-Bash)
#   Requires: JDK 11+, a running MySQL server, db/schema.sql already imported,
#             MySQL Connector/J jar inside lib/
set -e
cd "$(dirname "$0")"

if ! ls lib/*.jar >/dev/null 2>&1; then
  echo "No JDBC driver found in the lib/ folder."
  echo "Download MySQL Connector/J (Platform Independent) from https://dev.mysql.com/downloads/connector/j/"
  echo "and copy mysql-connector-j-<version>.jar into lib/ , then run this script again."
  exit 1
fi

rm -rf out && mkdir -p out
# -sourcepath lets javac find every other class that Main uses, so no file list is needed
javac --release 11 -encoding UTF-8 -sourcepath src -d out src/campus/Main.java
echo "Compiled OK."

# JAVA_OPTS is optional, e.g.  JAVA_OPTS="-Dcampus.config=/path/other.properties" ./run.sh
exec java $JAVA_OPTS -cp "out:lib/*" campus.Main
