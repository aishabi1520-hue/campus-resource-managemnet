# Viva questions and short answers

**1. What are the steps of JDBC?**
Load the driver (`Class.forName`), open a connection (`DriverManager.getConnection` — see `Db.java`), create a `PreparedStatement`, execute it (`executeQuery` / `executeUpdate`), read the `ResultSet`, and close everything (we use try-with-resources so it closes automatically).

**2. Why `PreparedStatement` instead of `Statement`?**
It sends the SQL and the values separately, so user input can never change the structure of the query — this prevents SQL injection. It is also faster when repeated and handles quoting and types for you.

**3. How do you stop two people booking the same slot?**
Two layers. First, an overlap query: a new slot clashes if `existing.start < new.end AND existing.end > new.start`. Second, `BookingDao.create()` runs as a **transaction** and first locks the resource row with `SELECT … FOR UPDATE`, so simultaneous requests for that resource are processed one at a time. Tested with 12 simultaneous requests — exactly one succeeds.

**4. What is a transaction? Where is it used?**
A group of statements that either all succeed or all fail (ACID). In `BookingDao.create()` we call `setAutoCommit(false)`, do lock → check → insert, then `commit()`; on any error we `rollback()`.

**5. What is the difference between `executeQuery` and `executeUpdate`?**
`executeQuery` runs a `SELECT` and returns a `ResultSet`. `executeUpdate` runs `INSERT/UPDATE/DELETE` and returns the number of rows changed (we use that to detect, for example, that a request was already approved).

**6. How are passwords stored?**
Never as plain text. We use PBKDF2-HMAC-SHA256 with a random salt per user and 120,000 iterations (`Passwords.java`). On login we hash the typed password with the stored salt and compare in constant time.

**7. Explain the database design / normalisation.**
Four tables: `users`, `categories`, `resources`, `bookings`. Category names live in their own table (no repeating text), bookings reference users and resources with foreign keys. Each table has a single-column primary key and no repeating groups or partial dependencies, so it is in 3NF.

**8. Why can't I delete a resource that has bookings?**
The foreign key `bookings.resource_id → resources.resource_id` makes MySQL refuse (SQLState `23000`). We catch it and show a friendly message; the admin can deactivate the resource instead, which keeps the history.

**9. What is MVC here?**
Model = `model` + `dao` packages (data and database access). View = HTML produced in the controllers and `web/templates/layout.html`. Controller = the four `*Controller` classes. A `service` layer sits between controller and DAO for business rules, and `Router` is the front controller.

**10. How do sessions work?**
After login the server creates a random session id, stores the user in a server-side map, and sends the id in an `HttpOnly` cookie. Every request looks the session up. A new id is issued at login (prevents session fixation), and sessions expire after 30 minutes idle.

**11. What are XSS and CSRF, and how are they handled?**
XSS = a user injects script that runs in other users' browsers; we HTML-escape all user text (`Html.esc`) and send a Content-Security-Policy header. CSRF = another website tricks your browser into submitting a request; every POST form contains a secret token that the server checks.

**12. Why not use Servlets/JSP or Spring?**
To keep the project dependency-free and the request flow transparent. The JDK has a built-in HTTP server; the JDBC/DAO code is exactly what a Servlet/JSP or Spring app would call. Moving to Servlets would mean replacing `Router`/`Ctx` with `HttpServlet` classes — the DAOs and services stay unchanged.

**13. Why are dates passed to MySQL as text (`"2026-10-05"`)?**
MySQL converts ISO text to `DATE`/`TIME` itself. It is driver-independent and avoids the time-zone shifting bugs that can appear when converting between `java.sql.Date` and the server's zone.

**14. How would you scale this?**
Add a connection pool (HikariCP) instead of opening a connection per query, move sessions to a shared store, put it behind HTTPS and a reverse proxy, and add indexes for new report queries (the `idx_slot` index already serves the clash check).
