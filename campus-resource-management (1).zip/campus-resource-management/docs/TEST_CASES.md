# Test cases and results

All cases below were executed against the running application and a real database (73 automated checks in total; this table groups them). Dates are relative to "today" when the test runs.

| ID | Module | Scenario | Expected result | Result |
|----|--------|----------|-----------------|--------|
| T01 | Auth | Open `/dashboard` without logging in | Redirected to login with "Please log in" | PASS |
| T02 | Auth | Login with wrong password | "Invalid email or password" | PASS |
| T03 | Auth | Login with SQL injection text `' OR '1'='1' --` as email | Login fails, no error | PASS |
| T04 | Auth | Valid student login | Dashboard opens; session id changes | PASS |
| T05 | Auth | Submit a form without the CSRF token | HTTP 403 | PASS |
| T06 | Auth | Logout, then open a protected page | Redirected to login | PASS |
| T07 | Access | Student opens `/admin/resources`, `/admin/bookings` | HTTP 403 "administrators only" | PASS |
| T08 | Register | Short name / bad email / short password / mismatched passwords / duplicate email | Each rejected with a clear message | PASS |
| T09 | Register | Send `role=ADMIN` in the registration form | Account is created as STUDENT | PASS |
| T10 | Register | Inspect `password_hash` in the database | Starts with `pbkdf2$`, not the plain password | PASS |
| T11 | Resources | List as student | All 12 active resources shown | PASS |
| T12 | Resources | Filter by category *Computer Lab* | 2 resources | PASS |
| T13 | Resources | Search "projector" | 1 resource | PASS |
| T14 | Resources | Search text `' OR 1=1 --` | 0 results, no error | PASS |
| T15 | Booking | Valid student request | Saved as PENDING | PASS |
| T16 | Booking | Overlap: new slot starts inside / ends inside / sits inside an existing booking | "Time slot clash" with the existing times; typed values kept | PASS |
| T17 | Booking | Back-to-back slots (one ends exactly when the next starts) | Both accepted | PASS |
| T18 | Booking | Same time slot on a different resource | Accepted | PASS |
| T19 | Booking | Past date; end before start; before 08:00; after 20:00; over 4 h; under 30 min; purpose under 3 chars; more than 60 days ahead; invalid date | Each rejected with its own message | PASS |
| T20 | Booking | Unknown resource id | HTTP 404 | PASS |
| T21 | Booking | Book a deactivated resource | "currently unavailable" | PASS |
| T22 | Concurrency | 12 users request the same slot at the same moment | Exactly 1 succeeds, 11 get "clash"; 1 row in the table | PASS |
| T23 | Integrity | Self-join on `bookings` after all tests | 0 overlapping pending/approved bookings | PASS |
| T24 | Workflow | Admin approves a pending request with a remark | Status APPROVED; student sees status and remark | PASS |
| T25 | Workflow | Admin tries to decide the same request again | "already handled", status unchanged | PASS |
| T26 | Workflow | Admin rejects a request | REJECTED; the slot can be booked again | PASS |
| T27 | Workflow | Send an invalid decision value | Refused (HTTP 403) | PASS |
| T28 | Workflow | Faculty makes a booking | Approved immediately | PASS |
| T29 | Cancel | Student cancels own booking | CANCELLED; slot free again | PASS |
| T30 | Cancel | Student tries to cancel another user's booking | Refused; booking unchanged | PASS |
| T31 | Admin | Add, edit, deactivate a resource | Saved; inactive resource hidden from students, still visible to admin | PASS |
| T32 | Admin | Invalid capacity (`abc`) | "Capacity must be a number…", form re-shown | PASS |
| T33 | Admin | Delete a resource that has bookings | Refused with a friendly message (foreign key) | PASS |
| T34 | Admin | Delete a resource with no bookings | Deleted | PASS |
| T35 | Report | Open usage report | Table + bars shown; "approved hours" equals the value computed directly in SQL | PASS |
| T36 | Security | Register with name `<script>alert(1)</script>`, purpose `<img src=x onerror=…>` | Shown as harmless text on every page (dashboard, My Bookings, admin lists) | PASS |
| T37 | Security | Request `/static/../config/db.properties` | HTTP 404 (path traversal blocked) | PASS |
| T38 | General | Unknown URL | Friendly 404 page | PASS |

**Environment:** JDK 21 (compiled with `--release 11`), MariaDB 10.11 (MySQL-compatible) with its JDBC driver, headless Chromium for the screenshots.
