@echo off
rem Compile and start the Campus Resource Management System (Windows)
rem Requires: JDK 11+, a running MySQL server, db\schema.sql already imported,
rem           MySQL Connector/J jar inside lib\
cd /d "%~dp0"

if not exist "lib\*.jar" (
  echo No JDBC driver found in the lib\ folder.
  echo Download MySQL Connector/J ^(Platform Independent^) from https://dev.mysql.com/downloads/connector/j/
  echo and copy mysql-connector-j-^<version^>.jar into lib\ , then run this file again.
  pause
  exit /b 1
)

if exist out rmdir /s /q out
mkdir out

rem -sourcepath lets javac find every other class that Main uses, so no file list is needed
javac --release 11 -encoding UTF-8 -sourcepath src -d out src\campus\Main.java
if errorlevel 1 (
  echo Compilation failed.
  pause
  exit /b 1
)
echo Compiled OK.

java %JAVA_OPTS% -cp "out;lib\*" campus.Main
pause
