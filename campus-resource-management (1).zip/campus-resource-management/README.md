# Web-Based Campus Resource Management System
**Java · JDBC · MySQL** — a mini project for booking classrooms, labs, halls and equipment on a campus.

Students and faculty browse resources and book time slots. The system prevents double-booking, admins approve or reject student requests, and reports show how much each resource is used.

![Booking clash detection](docs/screenshots/04-booking-clash.png)

---

## 1. Quick start (5 steps)

**You need:** JDK 11 or newer, MySQL 8 (or 5.7+), and the MySQL JDBC driver jar.

| # | Step | Command / action |
|---|------|------------------|
| 1 | Create the database and sample data | `mysql -u root -p < db/schema.sql` <br>*(PowerShell: `mysql -u root -p -e "source db/schema.sql"`, or run the file in MySQL Workbench)* |
| 2 | Add the JDBC driver | Download **Connector/J** (Platform Independent) from <https://dev.mysql.com/downloads/connector/j/> and copy `mysql-connector-j-<version>.jar` into the `lib/` folder |
| 3 | Set your MySQL login | Edit `config/db.properties` → `db.user` and `db.password` |
| 4 | Compile and run | Linux/macOS: `./run.sh` · Windows: double-click `run.bat` |
| 5 | Open the app | <http://localhost:8080> |

Demo accounts are created automatically on first start:

| Role | Email | Password | Can do |
|------|-------|----------|--------|
| Admin | `admin@campus.edu` | `Admin@123` | everything + manage resources, approve requests, reports |
| Faculty | `faculty@campus.edu` | `Faculty@123` | book (approved instantly) |
| Student | `student@campus.edu` | `Student@123` | book (needs admin approval) |

**Using an IDE (Eclipse / IntelliJ / NetBeans)?** Create a plain Java project, copy the `src` folder in, add the Connector/J jar to the classpath, and run `campus.Main`. Set the **working directory to the project root** — the app looks for `config/` and `web/` relative to it.

### If something goes wrong

| Message | Fix |
|---------|-----|
| `JDBC driver ... not found` / `No suitable driver` | The jar is not in `lib/` |
| `Access denied for user` | Wrong `db.user` / `db.password` in `config/db.properties` |
| `Unknown database 'campus_db'` | Step 1 was not run |
| `Communications link failure` | MySQL is not running, or the port in `db.url` is not 3306 |
| `Address already in use` | Change `server.port` in `config/db.properties` |
| Page opens but has no styling | The app was started from the wrong folder — run it from the project root |

---

## 2. Features

**Everyone (logged in)**
- Register / sign in / sign out (passwords stored as salted PBKDF2 hashes)
- Dashboard with personal statistics and upcoming bookings
- Browse resources, filter by category, search by name or location
- Book a resource for a date and time range; see who has already booked it
- View and cancel own bookings (only before they start)

**Administrator**
- Add, edit, activate/deactivate and delete resources
- Approve or reject student requests, with remarks
- Usage report: bookings and booked hours per resource (SQL `JOIN` + `GROUP BY`)
- List of registered users

### Business rules

| Rule | Value |
|------|-------|
| Bookable hours | 08:00 – 20:00 |
| Length of one booking | 30 minutes – 4 hours |
| How far ahead | up to 60 days |
| Past dates / start times | rejected |
| Two bookings for one resource overlapping | **rejected** (pending and approved bookings both block the slot; back-to-back slots are fine) |
| Student booking | starts as `PENDING`, admin must approve |
| Faculty / admin booking | approved instantly |
| Reject / cancel | frees the slot again |
| Delete a resource that has bookings | blocked by a foreign key — deactivate it instead |

---

## 3. How it is built

```
 Browser
    │  HTTP
    ▼
 Router ── session · CSRF token · role check            (campus.web)
    │
    ▼
 Controllers ── AuthController · PortalController
    │           BookingController · AdminController     (campus.web)
    ▼
 Service ── BookingService: validation + business rules (campus.service)
    │
    ▼
 DAO ── UserDao · ResourceDao · BookingDao  (all JDBC)  (campus.dao)
    │
    ▼
 MySQL ── users · categories · resources · bookings     (db/schema.sql)
```

- **Why no Tomcat/Servlets?** The web layer uses the HTTP server that ships with the JDK (`com.sun.net.httpserver`). It means nothing to install except the JDBC driver, and it makes the request flow visible in about 300 lines (`Router`, `Ctx`) instead of hiding it in a framework. The DAO/JDBC layer — the focus of this project — is identical to what you would use under a Servlet/JSP app.
- **JDBC steps** are visible in `Db.java` (load driver, open connection) and the DAO classes (`PreparedStatement` → `executeQuery`/`executeUpdate` → `ResultSet`, closed with try-with-resources).
- **The most interesting method** is `BookingDao.create()`: a JDBC **transaction** that locks the resource row (`SELECT … FOR UPDATE`), checks for an overlapping slot, inserts, and commits — so two people cannot book the same slot even at the same instant.

### Database design

```mermaid
erDiagram
    CATEGORIES ||--o{ RESOURCES : groups
    RESOURCES  ||--o{ BOOKINGS  : "is booked in"
    USERS      ||--o{ BOOKINGS  : makes

    USERS {
        int user_id PK
        varchar full_name
        varchar email UK
        varchar password_hash
        enum role "ADMIN, FACULTY, STUDENT"
        varchar department
        timestamp created_at
    }
    CATEGORIES {
        int category_id PK
        varchar name UK
    }
    RESOURCES {
        int resource_id PK
        varchar name
        int category_id FK
        varchar location
        int capacity
        varchar description
        tinyint is_active
    }
    BOOKINGS {
        int booking_id PK
        int resource_id FK
        int user_id FK
        date booking_date
        time start_time
        time end_time
        varchar purpose
        enum status "PENDING, APPROVED, REJECTED, CANCELLED"
        varchar admin_remarks
        timestamp created_at
    }
```

*(An image of this diagram for your report is in `docs/er-diagram.png`.)*

The overlap test used for clash detection — two slots overlap when each starts before the other ends:

```sql
SELECT start_time, end_time, status FROM bookings
WHERE resource_id = ? AND booking_date = ?
  AND status IN ('PENDING','APPROVED')
  AND start_time < :new_end AND end_time > :new_start;
```

### Security measures
- **SQL injection:** every query that takes user input uses `PreparedStatement`
- **XSS:** all user-supplied text is HTML-escaped before it is written to a page (`Html.esc`), plus a `Content-Security-Policy` header
- **CSRF:** every POST form carries a random token that is checked on the server
- **Passwords:** PBKDF2-HMAC-SHA256, 120,000 iterations, random salt per user
- **Sessions:** random 192-bit ids, `HttpOnly` + `SameSite=Lax` cookie, new id on login, 30-minute idle timeout
- **Access control:** each route is marked public / user / admin and enforced centrally in `Router`; users can only cancel their own bookings
- **Registration** can never create an admin, whatever is sent in the form

*(For a real deployment you would also serve it over HTTPS and add the cookie `Secure` flag, and remove the demo-accounts box from the login page.)*

---

## 4. Screenshots

| | |
|---|---|
| ![](docs/screenshots/01-login.png) **Login** | ![](docs/screenshots/02-student-dashboard.png) **Student dashboard** |
| ![](docs/screenshots/03-resources-filtered.png) **Browse / filter resources** | ![](docs/screenshots/05-my-bookings.png) **My bookings** (statuses, admin remarks, cancel) |
| ![](docs/screenshots/07-admin-requests.png) **Admin: approve / reject** | ![](docs/screenshots/08-admin-resources.png) **Admin: manage resources** |
| ![](docs/screenshots/06-admin-dashboard.png) **Admin dashboard** | ![](docs/screenshots/09-admin-reports.png) **Usage report** |

---

## 5. Demo script (about 8 minutes)

Have two browser windows ready (or one normal + one private window): one for the **student**, one for the **admin**. Start the app first.

1. **Introduce (1 min).** Show the architecture diagram above. Say: browser → router → controller → service → DAO → MySQL, and that the DAO layer is plain JDBC.
2. **Register (1 min).** Click *Register*, create a student account. Try a short password and a duplicate email to show validation. In MySQL run `SELECT email, role, password_hash FROM users;` — point out the hash is not the password.
3. **Book as student (1.5 min).** Log in as `student@campus.edu` → *Resources* → filter *Computer Lab* → *Book this resource* on **Computer Lab A** → pick tomorrow 10:00–12:00, purpose "Java lab practice" → submit. It appears in *My Bookings* as **PENDING**.
4. **Show clash detection (1 min).** Book the same lab 11:00–13:00. The error shows the exact conflicting slot, and the form keeps your input. Then book 12:00–13:00 — accepted, because it only *touches* the first booking.
5. **Approve as admin (1.5 min).** In the other window log in as `admin@campus.edu`. The nav shows **Requests (n)**. Open it, type a remark, click **Approve** on the first one and **Reject** on another. Open *Reports* to show the usage table update.
6. **Back to the student (0.5 min).** Refresh *My Bookings*: status is **APPROVED** with the remark; the rejected one shows its reason. Cancel one booking and show the slot is free again.
7. **Manage resources (1 min).** As admin: *Manage Resources* → *Add resource* → edit it → *Deactivate* (it disappears for students) → try to *Delete* **Computer Lab A** and show the friendly refusal (foreign key), then delete the new unused one.
8. **Show the database (0.5 min).**
   ```sql
   SELECT b.booking_id, r.name AS resource, u.full_name AS user,
          b.booking_date, b.start_time, b.end_time, b.status
   FROM bookings b JOIN resources r USING (resource_id) JOIN users u USING (user_id);
   ```
9. **Show one piece of code (if asked).** Open `BookingDao.create()` and walk through *lock → check overlap → insert → commit/rollback*. Likely examiner questions and short answers are in [`docs/VIVA_QA.md`](docs/VIVA_QA.md).

**Tip:** run the demo on a fresh database (`db/schema.sql`, then restart the app) so the lists are not cluttered with test data.

---

## 6. Testing

73 automated end-to-end checks were run against the running application and a real database — all passed. They cover login and access control, every booking rule, clash detection (including boundary cases), the approve/reject/cancel workflow, resource management, SQL-injection and XSS attempts, CSRF, and a **concurrency test where 12 users request the same slot at once: exactly one succeeds** and the database is left with no overlapping bookings. See [`docs/TEST_CASES.md`](docs/TEST_CASES.md) for the test-case table you can paste into a report.

**Tested with:** JDK 21 (compiled with `--release 11`), MariaDB 10.11 (MySQL-compatible) and its JDBC driver. The code uses only standard JDBC and standard MySQL SQL, so Oracle MySQL + Connector/J only changes the driver class and URL in `config/db.properties`. I could not run it against Oracle MySQL Server itself in my environment, so do a quick run-through of the demo steps on your machine before presenting. `run.bat` (Windows) was not run in my environment either; `run.sh` was.

---

## 7. Project structure

```
campus-resource-management/
├── run.sh · run.bat            compile + start
├── config/db.properties        database login, port
├── db/schema.sql               tables + sample resources
├── lib/                        put the MySQL Connector/J jar here
├── web/
│   ├── templates/layout.html   page shell (header, menu, footer)
│   └── static/                 style.css, app.js
├── docs/                       screenshots, test cases, viva Q&A
└── src/campus/
    ├── Main.java               start-up: config → DB check → seed → server
    ├── db/Db.java              JDBC connection helper
    ├── model/                  User, Resource, Category, Booking (plain Java objects)
    ├── dao/                    UserDao, ResourceDao, BookingDao, DataSeeder  ← all SQL lives here
    ├── service/                BookingService (rules), BookingException
    ├── util/                   Passwords (PBKDF2), Html (escaping, formatting)
    └── web/                    Router, Ctx, Session(s), Layout, 4 controllers
```

## 8. Possible extensions
Email notification on approval · recurring bookings · calendar view · department-wise quotas · CSV/PDF export of reports · connection pooling (HikariCP) · migrate the controllers to Servlets/JSP or Spring Boot.
