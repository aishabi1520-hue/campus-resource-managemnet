-- ============================================================
--  Campus Resource Management System  -  MySQL schema + sample data
--  Run once:   mysql -u root -p < db/schema.sql
--  WARNING: re-running this file drops the tables and resets the data.
-- ============================================================

CREATE DATABASE IF NOT EXISTS campus_db
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campus_db;

DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS resources;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;

-- ------------------------------------------------------------
-- users : everybody who can log in (the app seeds 3 demo users
--         with hashed passwords on first start)
-- ------------------------------------------------------------
CREATE TABLE users (
    user_id        INT AUTO_INCREMENT PRIMARY KEY,
    full_name      VARCHAR(100) NOT NULL,
    email          VARCHAR(120) NOT NULL UNIQUE,
    password_hash  VARCHAR(255) NOT NULL,
    role           ENUM('ADMIN','FACULTY','STUDENT') NOT NULL DEFAULT 'STUDENT',
    department     VARCHAR(80),
    created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- categories : kinds of resource (Classroom, Lab, Equipment ...)
-- ------------------------------------------------------------
CREATE TABLE categories (
    category_id    INT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(60) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- resources : the things that can be booked
-- ------------------------------------------------------------
CREATE TABLE resources (
    resource_id    INT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(100) NOT NULL,
    category_id    INT NOT NULL,
    location       VARCHAR(120) NOT NULL,
    capacity       INT NOT NULL DEFAULT 1,
    description    VARCHAR(300),
    is_active      TINYINT(1) NOT NULL DEFAULT 1,
    CONSTRAINT fk_resource_category FOREIGN KEY (category_id) REFERENCES categories(category_id),
    CONSTRAINT chk_capacity CHECK (capacity > 0)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- bookings : a user reserves a resource for a time slot
-- ------------------------------------------------------------
CREATE TABLE bookings (
    booking_id     INT AUTO_INCREMENT PRIMARY KEY,
    resource_id    INT NOT NULL,
    user_id        INT NOT NULL,
    booking_date   DATE NOT NULL,
    start_time     TIME NOT NULL,
    end_time       TIME NOT NULL,
    purpose        VARCHAR(200) NOT NULL,
    status         ENUM('PENDING','APPROVED','REJECTED','CANCELLED') NOT NULL DEFAULT 'PENDING',
    admin_remarks  VARCHAR(200) NULL,
    created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_booking_resource FOREIGN KEY (resource_id) REFERENCES resources(resource_id),
    CONSTRAINT fk_booking_user     FOREIGN KEY (user_id)     REFERENCES users(user_id),
    CONSTRAINT chk_booking_time    CHECK (end_time > start_time),
    INDEX idx_slot (resource_id, booking_date, start_time, end_time),
    INDEX idx_user (user_id, booking_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Sample data
-- ------------------------------------------------------------
INSERT INTO categories (name) VALUES
    ('Classroom'), ('Computer Lab'), ('Laboratory'), ('Seminar Hall'),
    ('Auditorium'), ('Sports Facility'), ('Equipment');

INSERT INTO resources (name, category_id, location, capacity, description) VALUES
    ('Classroom 101',      1, 'Main Block, Ground Floor',  60,  'Smart board, projector and 60 seats.'),
    ('Classroom 204',      1, 'Main Block, 2nd Floor',     45,  'Air-conditioned, whiteboard, projector.'),
    ('Computer Lab A',     2, 'IT Block, 1st Floor',       40,  '40 desktops, high-speed LAN, projector.'),
    ('Computer Lab B',     2, 'IT Block, 2nd Floor',       30,  '30 desktops with development software installed.'),
    ('Physics Lab',        3, 'Science Block, Ground Floor', 30, 'Optics and mechanics experiment benches.'),
    ('Chemistry Lab',      3, 'Science Block, 1st Floor',  25,  'Fume hoods and safety equipment included.'),
    ('Seminar Hall 1',     4, 'Admin Block, 1st Floor',    120, 'Stage, podium, audio system and projector.'),
    ('Conference Room',    4, 'Admin Block, 2nd Floor',    20,  'Meeting-style seating with video conferencing.'),
    ('Main Auditorium',    5, 'Campus Centre',             500, 'Fixed seating, stage lighting, full sound system.'),
    ('Basketball Court',   6, 'Sports Complex',            20,  'Indoor court with floodlights.'),
    ('Portable Projector', 7, 'AV Store, Admin Block',     1,   'Full HD projector with HDMI and VGA cables.'),
    ('DSLR Camera Kit',    7, 'AV Store, Admin Block',     1,   'Camera, two lenses, tripod and spare battery.');
