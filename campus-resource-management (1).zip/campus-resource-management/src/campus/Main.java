package campus;

import campus.dao.DataSeeder;
import campus.db.Db;
import campus.web.AdminController;
import campus.web.AuthController;
import campus.web.BookingController;
import campus.web.PortalController;
import campus.web.Router;
import com.sun.net.httpserver.HttpServer;

import java.net.InetSocketAddress;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.Executors;

/**
 * Campus Resource Management System - entry point.
 * Run:  ./run.sh   (Linux/macOS)   or   run.bat   (Windows)
 */
public class Main {

    public static void main(String[] args) throws Exception {
        String configFile = System.getProperty("campus.config", "config/db.properties");
        Db.load(configFile);

        // 1. Make sure we can talk to MySQL before starting the web server
        try (Connection con = Db.connect()) {
            System.out.println("Connected to " + con.getMetaData().getDatabaseProductName()
                    + " " + con.getMetaData().getDatabaseProductVersion());
        } catch (SQLException e) {
            System.err.println("\nCould not connect to the database: " + e.getMessage());
            System.err.println("Check that MySQL is running, that db/schema.sql has been run,");
            System.err.println("and that the user/password in " + configFile + " are correct.");
            System.exit(1);
        }

        // 2. Demo accounts (first start only)
        DataSeeder.seedUsersIfEmpty();

        // 3. Wire controllers into the router
        Router router = new Router();
        new AuthController().register(router);
        new PortalController().register(router);
        new BookingController().register(router);
        new AdminController().register(router);

        // 4. Start the web server (built into the JDK - no Tomcat needed)
        String host = Db.setting("server.host", "localhost");
        int port = Integer.parseInt(Db.setting("server.port", "8080"));
        HttpServer server = HttpServer.create(new InetSocketAddress(host, port), 0);
        server.createContext("/", router);
        server.setExecutor(Executors.newFixedThreadPool(16));
        server.start();
        System.out.println("Campus Resource Management System running at http://" + host + ":" + port + "/");
        System.out.println("Press Ctrl+C to stop.");
    }
}
