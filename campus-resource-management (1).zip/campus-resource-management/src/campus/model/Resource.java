package campus.model;

/** Something on campus that can be booked (room, lab, hall, equipment ...). */
public class Resource {

    private final int id;
    private final String name;
    private final int categoryId;
    private final String categoryName;
    private final String location;
    private final int capacity;
    private final String description;
    private final boolean active;

    public Resource(int id, String name, int categoryId, String categoryName,
                    String location, int capacity, String description, boolean active) {
        this.id = id;
        this.name = name;
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.location = location;
        this.capacity = capacity;
        this.description = description;
        this.active = active;
    }

    public int getId()               { return id; }
    public String getName()          { return name; }
    public int getCategoryId()       { return categoryId; }
    public String getCategoryName()  { return categoryName; }
    public String getLocation()      { return location; }
    public int getCapacity()         { return capacity; }
    public String getDescription()   { return description; }
    public boolean isActive()        { return active; }
}
