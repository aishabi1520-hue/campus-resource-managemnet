package campus.model;

/** A person who can log in. The password hash is never stored in this object. */
public class User {

    public enum Role { ADMIN, FACULTY, STUDENT }

    private final int id;
    private final String fullName;
    private final String email;
    private final Role role;
    private final String department;
    private final String createdAt;

    public User(int id, String fullName, String email, Role role, String department, String createdAt) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.role = role;
        this.department = department;
        this.createdAt = createdAt;
    }

    public int getId()            { return id; }
    public String getFullName()   { return fullName; }
    public String getEmail()      { return email; }
    public Role getRole()         { return role; }
    public String getDepartment() { return department; }
    public String getCreatedAt()  { return createdAt; }

    public boolean isAdmin()      { return role == Role.ADMIN; }
}
