package campus.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/** A reservation of one resource, by one user, for one time slot. */
public class Booking {

    public enum Status { PENDING, APPROVED, REJECTED, CANCELLED }

    private final int id;
    private final int resourceId;
    private final String resourceName;
    private final int userId;
    private final String userName;
    private final String userEmail;
    private final LocalDate date;
    private final LocalTime startTime;
    private final LocalTime endTime;
    private final String purpose;
    private final Status status;
    private final String adminRemarks;
    private final String createdAt;

    public Booking(int id, int resourceId, String resourceName, int userId, String userName, String userEmail,
                   LocalDate date, LocalTime startTime, LocalTime endTime, String purpose,
                   Status status, String adminRemarks, String createdAt) {
        this.id = id;
        this.resourceId = resourceId;
        this.resourceName = resourceName;
        this.userId = userId;
        this.userName = userName;
        this.userEmail = userEmail;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.purpose = purpose;
        this.status = status;
        this.adminRemarks = adminRemarks;
        this.createdAt = createdAt;
    }

    public int getId()              { return id; }
    public int getResourceId()      { return resourceId; }
    public String getResourceName() { return resourceName; }
    public int getUserId()          { return userId; }
    public String getUserName()     { return userName; }
    public String getUserEmail()    { return userEmail; }
    public LocalDate getDate()      { return date; }
    public LocalTime getStartTime() { return startTime; }
    public LocalTime getEndTime()   { return endTime; }
    public String getPurpose()      { return purpose; }
    public Status getStatus()       { return status; }
    public String getAdminRemarks() { return adminRemarks; }
    public String getCreatedAt()    { return createdAt; }

    /** True while the booking is still active (waiting or approved) and has not started yet. */
    public boolean isCancellable(LocalDateTime now) {
        boolean active = status == Status.PENDING || status == Status.APPROVED;
        return active && LocalDateTime.of(date, startTime).isAfter(now);
    }

    /** True for an active booking whose slot has not finished yet. */
    public boolean isUpcoming(LocalDateTime now) {
        boolean active = status == Status.PENDING || status == Status.APPROVED;
        return active && LocalDateTime.of(date, endTime).isAfter(now);
    }
}
