package campus.util;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Map;

/** Small helpers for building HTML safely. Every user-supplied value must go through esc(). */
public final class Html {

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy", Locale.ENGLISH);
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");

    private Html() { }

    /** Escapes &lt; &gt; &amp; and quotes - this is what prevents cross-site scripting (XSS). */
    public static String esc(String s) {
        if (s == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '&':  sb.append("&amp;");  break;
                case '<':  sb.append("&lt;");   break;
                case '>':  sb.append("&gt;");   break;
                case '"':  sb.append("&quot;"); break;
                case '\'': sb.append("&#39;");  break;
                default:   sb.append(ch);
            }
        }
        return sb.toString();
    }

    public static String date(LocalDate d) {
        return d.format(DATE_FMT);
    }

    public static String time(LocalTime t) {
        return t.format(TIME_FMT);
    }

    /** Trims a database timestamp such as "2026-10-04 21:40:00.0" to "2026-10-04 21:40". */
    public static String timestamp(String ts) {
        if (ts == null) {
            return "";
        }
        return ts.length() > 16 ? ts.substring(0, 16) : ts;
    }

    public static String badge(String status) {
        return "<span class=\"badge badge-" + status.toLowerCase() + "\">" + esc(status) + "</span>";
    }

    /** A label + input pair. */
    public static String field(String label, String inputHtml) {
        return "<label class=\"field\"><span>" + esc(label) + "</span>" + inputHtml + "</label>";
    }

    /** A drop-down. options: value -> visible text (insertion order is kept by LinkedHashMap). */
    public static String select(String name, Map<String, String> options, String selected) {
        StringBuilder sb = new StringBuilder("<select name=\"" + esc(name) + "\">");
        for (Map.Entry<String, String> e : options.entrySet()) {
            sb.append("<option value=\"").append(esc(e.getKey())).append("\"");
            if (e.getKey().equals(selected)) {
                sb.append(" selected");
            }
            sb.append(">").append(esc(e.getValue())).append("</option>");
        }
        return sb.append("</select>").toString();
    }
}
