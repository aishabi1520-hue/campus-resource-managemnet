package campus.service;

import campus.dao.BookingDao;
import campus.model.Booking;
import campus.model.User;

import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;

/**
 * Business rules for booking requests. The controller calls this class;
 * this class validates and then calls the DAO. (Controller -> Service -> DAO -> MySQL)
 */
public final class BookingService {

    public static final LocalTime OPENING = LocalTime.of(8, 0);
    public static final LocalTime CLOSING = LocalTime.of(20, 0);
    public static final int MIN_MINUTES = 30;
    public static final int MAX_MINUTES = 4 * 60;
    public static final int ADVANCE_DAYS = 60;

    private BookingService() { }

    /**
     * Validates and stores a booking request.
     * Policy: students need admin approval (PENDING); faculty and admins are approved instantly.
     *
     * @return the status the new booking received
     */
    public static Booking.Status submit(User user, int resourceId, String dateText, String startText,
                                        String endText, String purposeText)
            throws BookingException, SQLException {

        LocalDate date;
        LocalTime start;
        LocalTime end;
        try {
            date = LocalDate.parse(dateText);
            start = LocalTime.parse(startText);
            end = LocalTime.parse(endText);
        } catch (DateTimeParseException | NullPointerException e) {
            throw new BookingException("Please enter a valid date, start time and end time.");
        }
        start = start.withSecond(0).withNano(0);
        end = end.withSecond(0).withNano(0);

        String purpose = purposeText == null ? "" : purposeText.trim();
        if (purpose.length() < 3 || purpose.length() > 200) {
            throw new BookingException("Purpose must be between 3 and 200 characters.");
        }

        LocalDateTime now = LocalDateTime.now();
        if (date.isBefore(now.toLocalDate())) {
            throw new BookingException("You cannot book a date in the past.");
        }
        if (date.isAfter(now.toLocalDate().plusDays(ADVANCE_DAYS))) {
            throw new BookingException("Bookings can only be made up to " + ADVANCE_DAYS + " days in advance.");
        }
        if (!end.isAfter(start)) {
            throw new BookingException("End time must be after the start time.");
        }
        if (start.isBefore(OPENING) || end.isAfter(CLOSING)) {
            throw new BookingException("Resources can be booked between 08:00 and 20:00 only.");
        }
        long minutes = Duration.between(start, end).toMinutes();
        if (minutes < MIN_MINUTES) {
            throw new BookingException("The minimum booking length is " + MIN_MINUTES + " minutes.");
        }
        if (minutes > MAX_MINUTES) {
            throw new BookingException("The maximum booking length is " + (MAX_MINUTES / 60) + " hours.");
        }
        if (LocalDateTime.of(date, start).isBefore(now)) {
            throw new BookingException("That start time has already passed.");
        }

        Booking.Status status = user.getRole() == User.Role.STUDENT
                ? Booking.Status.PENDING
                : Booking.Status.APPROVED;

        BookingDao.create(resourceId, user.getId(), date, start, end, purpose, status);
        return status;
    }
}
