package campus.service;

/** A business-rule problem with a booking request. The message is safe to show to the user. */
public class BookingException extends Exception {

    private static final long serialVersionUID = 1L;

    public BookingException(String message) {
        super(message);
    }
}
