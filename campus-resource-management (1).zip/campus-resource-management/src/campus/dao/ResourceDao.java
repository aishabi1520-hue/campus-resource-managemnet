package campus.dao;

import campus.db.Db;
import campus.model.Category;
import campus.model.Resource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/** All SQL for the resources and categories tables. */
public final class ResourceDao {

    private ResourceDao() { }

    private static final String BASE =
            "SELECT r.resource_id, r.name, r.category_id, c.name AS category_name, "
          + "r.location, r.capacity, r.description, r.is_active "
          + "FROM resources r JOIN categories c ON c.category_id = r.category_id";

    private static Resource map(ResultSet rs) throws SQLException {
        return new Resource(
                rs.getInt("resource_id"),
                rs.getString("name"),
                rs.getInt("category_id"),
                rs.getString("category_name"),
                rs.getString("location"),
                rs.getInt("capacity"),
                rs.getString("description"),
                rs.getInt("is_active") == 1);
    }

    public static List<Category> categories() throws SQLException {
        List<Category> list = new ArrayList<>();
        try (Connection con = Db.connect();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT category_id, name FROM categories ORDER BY name")) {
            while (rs.next()) {
                list.add(new Category(rs.getInt("category_id"), rs.getString("name")));
            }
        }
        return list;
    }

    /** Search/filter. categoryId 0 = all categories; text matches name or location. */
    public static List<Resource> search(int categoryId, String text, boolean onlyActive) throws SQLException {
        StringBuilder sql = new StringBuilder(BASE).append(" WHERE 1 = 1");
        List<Object> args = new ArrayList<>();
        if (categoryId > 0) {
            sql.append(" AND r.category_id = ?");
            args.add(categoryId);
        }
        if (text != null && !text.trim().isEmpty()) {
            sql.append(" AND (r.name LIKE ? OR r.location LIKE ?)");
            String like = "%" + text.trim() + "%";
            args.add(like);
            args.add(like);
        }
        if (onlyActive) {
            sql.append(" AND r.is_active = 1");
        }
        sql.append(" ORDER BY c.name, r.name");

        List<Resource> list = new ArrayList<>();
        try (Connection con = Db.connect(); PreparedStatement ps = con.prepareStatement(sql.toString())) {
            for (int i = 0; i < args.size(); i++) {
                ps.setObject(i + 1, args.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    public static Resource find(int id) throws SQLException {
        try (Connection con = Db.connect(); PreparedStatement ps = con.prepareStatement(BASE + " WHERE r.resource_id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public static int countActive() throws SQLException {
        try (Connection con = Db.connect();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM resources WHERE is_active = 1")) {
            rs.next();
            return rs.getInt(1);
        }
    }

    public static int insert(String name, int categoryId, String location, int capacity,
                             String description, boolean active) throws SQLException {
        String sql = "INSERT INTO resources (name, category_id, location, capacity, description, is_active) "
                   + "VALUES (?,?,?,?,?,?)";
        try (Connection con = Db.connect();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name);
            ps.setInt(2, categoryId);
            ps.setString(3, location);
            ps.setInt(4, capacity);
            ps.setString(5, description);
            ps.setInt(6, active ? 1 : 0);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    public static void update(int id, String name, int categoryId, String location, int capacity,
                              String description, boolean active) throws SQLException {
        String sql = "UPDATE resources SET name=?, category_id=?, location=?, capacity=?, description=?, is_active=? "
                   + "WHERE resource_id=?";
        try (Connection con = Db.connect(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setInt(2, categoryId);
            ps.setString(3, location);
            ps.setInt(4, capacity);
            ps.setString(5, description);
            ps.setInt(6, active ? 1 : 0);
            ps.setInt(7, id);
            ps.executeUpdate();
        }
    }

    public static void setActive(int id, boolean active) throws SQLException {
        try (Connection con = Db.connect();
             PreparedStatement ps = con.prepareStatement("UPDATE resources SET is_active = ? WHERE resource_id = ?")) {
            ps.setInt(1, active ? 1 : 0);
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }

    /**
     * Deletes a resource. If it already has bookings the foreign key makes MySQL refuse
     * (SQLState 23000) - the caller shows a friendly message and suggests deactivating instead.
     */
    public static void delete(int id) throws SQLException {
        try (Connection con = Db.connect();
             PreparedStatement ps = con.prepareStatement("DELETE FROM resources WHERE resource_id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}
