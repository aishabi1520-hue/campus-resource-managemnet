package campus.dao;

import campus.model.User;

import java.sql.SQLException;

/**
 * Creates the three demo accounts the first time the app starts (when the users table is empty).
 * Passwords are hashed by Java, which is why this is done here and not in schema.sql.
 */
public final class DataSeeder {

    private DataSeeder() { }

    public static void seedUsersIfEmpty() throws SQLException {
        if (UserDao.count() > 0) {
            return;
        }
        UserDao.create("Campus Admin",   "admin@campus.edu",   "Admin@123",   User.Role.ADMIN,   "Administration");
        UserDao.create("Dr. Meera Nair", "faculty@campus.edu", "Faculty@123", User.Role.FACULTY, "Computer Science");
        UserDao.create("Arjun Kumar",    "student@campus.edu", "Student@123", User.Role.STUDENT, "Computer Science");
        System.out.println("Seeded demo users: admin@campus.edu, faculty@campus.edu, student@campus.edu");
    }
}
