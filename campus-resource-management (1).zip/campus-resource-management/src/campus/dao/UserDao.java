package campus.dao;

import campus.db.Db;
import campus.model.User;
import campus.util.Html;
import campus.util.Passwords;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/** All SQL for the users table. Every query uses PreparedStatement (prevents SQL injection). */
public final class UserDao {

    private UserDao() { }

    private static User map(ResultSet rs) throws SQLException {
        return new User(
                rs.getInt("user_id"),
                rs.getString("full_name"),
                rs.getString("email"),
                User.Role.valueOf(rs.getString("role")),
                rs.getString("department"),
                Html.timestamp(rs.getString("created_at")));
    }

    /** Returns the user if the email/password pair is correct, otherwise null. */
    public static User authenticate(String email, String password) throws SQLException {
        String sql = "SELECT user_id, full_name, email, password_hash, role, department, created_at "
                   + "FROM users WHERE email = ?";
        try (Connection con = Db.connect(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && Passwords.verify(password, rs.getString("password_hash"))) {
                    return map(rs);
                }
                return null;
            }
        }
    }

    public static boolean emailExists(String email) throws SQLException {
        String sql = "SELECT 1 FROM users WHERE email = ?";
        try (Connection con = Db.connect(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public static int create(String fullName, String email, String password,
                             User.Role role, String department) throws SQLException {
        String sql = "INSERT INTO users (full_name, email, password_hash, role, department) VALUES (?,?,?,?,?)";
        try (Connection con = Db.connect();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, fullName);
            ps.setString(2, email);
            ps.setString(3, Passwords.hash(password));
            ps.setString(4, role.name());
            ps.setString(5, department);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    public static int count() throws SQLException {
        try (Connection con = Db.connect();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM users")) {
            rs.next();
            return rs.getInt(1);
        }
    }

    public static List<User> listAll() throws SQLException {
        String sql = "SELECT user_id, full_name, email, role, department, created_at FROM users ORDER BY role, full_name";
        List<User> list = new ArrayList<>();
        try (Connection con = Db.connect();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(map(rs));
            }
        }
        return list;
    }
}
