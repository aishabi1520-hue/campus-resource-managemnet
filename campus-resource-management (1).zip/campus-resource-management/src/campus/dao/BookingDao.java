package campus.dao;

import campus.db.Db;
import campus.model.Booking;
import campus.service.BookingException;
import campus.util.Html;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * All SQL for the bookings table.
 *
 * Note on dates/times: they are passed to and read from JDBC as ISO text ("2026-10-05", "09:30:00").
 * MySQL converts them to DATE/TIME itself, which is portable across drivers and avoids
 * time-zone shifting problems between the JVM and the database server.
 */
public final class BookingDao {

    private BookingDao() { }

    private static final String BASE =
            "SELECT b.booking_id, b.resource_id, r.name AS resource_name, b.user_id, "
          + "u.full_name AS user_name, u.email AS user_email, b.booking_date, b.start_time, b.end_time, "
          + "b.purpose, b.status, b.admin_remarks, b.created_at "
          + "FROM bookings b "
          + "JOIN resources r ON r.resource_id = b.resource_id "
          + "JOIN users u ON u.user_id = b.user_id";

    private static Booking map(ResultSet rs) throws SQLException {
        return new Booking(
                rs.getInt("booking_id"),
                rs.getInt("resource_id"),
                rs.getString("resource_name"),
                rs.getInt("user_id"),
                rs.getString("user_name"),
                rs.getString("user_email"),
                LocalDate.parse(rs.getString("booking_date")),
                LocalTime.parse(rs.getString("start_time")),
                LocalTime.parse(rs.getString("end_time")),
                rs.getString("purpose"),
                Booking.Status.valueOf(rs.getString("status")),
                rs.getString("admin_remarks"),
                Html.timestamp(rs.getString("created_at")));
    }

    // ---------------------------------------------------------------------------------
    //  CREATE  - a JDBC transaction: lock -> check for clash -> insert -> commit
    // ---------------------------------------------------------------------------------
    public static int create(int resourceId, int userId, LocalDate date, LocalTime start, LocalTime end,
                             String purpose, Booking.Status status) throws SQLException, BookingException {
        try (Connection con = Db.connect()) {
            con.setAutoCommit(false);                       // begin transaction
            try {
                // 1. Lock the resource row. Two people booking the same resource at the same
                //    moment are processed one after the other, so a double booking is impossible.
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT is_active FROM resources WHERE resource_id = ? FOR UPDATE")) {
                    ps.setInt(1, resourceId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            throw new BookingException("That resource does not exist.");
                        }
                        if (rs.getInt(1) != 1) {
                            throw new BookingException("This resource is currently unavailable for booking.");
                        }
                    }
                }

                // 2. Clash check: two slots overlap when  existing.start < new.end  AND  existing.end > new.start
                String clash = "SELECT start_time, end_time, status FROM bookings "
                             + "WHERE resource_id = ? AND booking_date = ? AND status IN ('PENDING','APPROVED') "
                             + "AND start_time < ? AND end_time > ? LIMIT 1";
                try (PreparedStatement ps = con.prepareStatement(clash)) {
                    ps.setInt(1, resourceId);
                    ps.setString(2, date.toString());
                    ps.setString(3, end.toString());
                    ps.setString(4, start.toString());
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            String from = Html.time(LocalTime.parse(rs.getString("start_time")));
                            String to = Html.time(LocalTime.parse(rs.getString("end_time")));
                            throw new BookingException("Time slot clash: this resource is already "
                                    + rs.getString("status").toLowerCase() + " from " + from + " to " + to
                                    + " on that day. Please choose another slot.");
                        }
                    }
                }

                // 3. Insert the booking
                String insert = "INSERT INTO bookings (resource_id, user_id, booking_date, start_time, end_time, purpose, status) "
                              + "VALUES (?,?,?,?,?,?,?)";
                int newId;
                try (PreparedStatement ps = con.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, resourceId);
                    ps.setInt(2, userId);
                    ps.setString(3, date.toString());
                    ps.setString(4, start.toString());
                    ps.setString(5, end.toString());
                    ps.setString(6, purpose);
                    ps.setString(7, status.name());
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        keys.next();
                        newId = keys.getInt(1);
                    }
                }
                con.commit();                               // all-or-nothing
                return newId;
            } catch (SQLException | BookingException | RuntimeException e) {
                con.rollback();
                throw e;
            }
        }
    }

    // ---------------------------------------------------------------------------------
    //  READ
    // ---------------------------------------------------------------------------------
    public static List<Booking> listByUser(int userId) throws SQLException {
        return query(BASE + " WHERE b.user_id = ? ORDER BY b.booking_date DESC, b.start_time DESC", userId);
    }

    /** status == null -> all statuses. */
    public static List<Booking> listByStatus(Booking.Status status) throws SQLException {
        if (status == null) {
            return query(BASE + " ORDER BY b.created_at DESC, b.booking_id DESC");
        }
        return query(BASE + " WHERE b.status = ? ORDER BY b.booking_date, b.start_time", status.name());
    }

    /** Active (pending/approved) bookings of one resource from a date onwards - shown on the booking page. */
    public static List<Booking> upcomingForResource(int resourceId, LocalDate from) throws SQLException {
        return query(BASE + " WHERE b.resource_id = ? AND b.booking_date >= ? AND b.status IN ('PENDING','APPROVED') "
                          + "ORDER BY b.booking_date, b.start_time", resourceId, from.toString());
    }

    private static List<Booking> query(String sql, Object... args) throws SQLException {
        List<Booking> list = new ArrayList<>();
        try (Connection con = Db.connect(); PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) {
                ps.setObject(i + 1, args[i]);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    /** Number of bookings per status. userId 0 = everybody. */
    public static Map<Booking.Status, Integer> statusCounts(int userId) throws SQLException {
        Map<Booking.Status, Integer> counts = new EnumMap<>(Booking.Status.class);
        for (Booking.Status s : Booking.Status.values()) {
            counts.put(s, 0);
        }
        String sql = "SELECT status, COUNT(*) AS n FROM bookings"
                   + (userId > 0 ? " WHERE user_id = ?" : "") + " GROUP BY status";
        try (Connection con = Db.connect(); PreparedStatement ps = con.prepareStatement(sql)) {
            if (userId > 0) {
                ps.setInt(1, userId);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    counts.put(Booking.Status.valueOf(rs.getString("status")), rs.getInt("n"));
                }
            }
        }
        return counts;
    }

    // ---------------------------------------------------------------------------------
    //  UPDATE
    // ---------------------------------------------------------------------------------

    /** A user cancels their own booking, only if it has not started yet. Returns true if a row changed. */
    public static boolean cancel(int bookingId, int userId, LocalDateTime now) throws SQLException {
        String sql = "UPDATE bookings SET status = 'CANCELLED' "
                   + "WHERE booking_id = ? AND user_id = ? AND status IN ('PENDING','APPROVED') "
                   + "AND (booking_date > ? OR (booking_date = ? AND start_time > ?))";
        try (Connection con = Db.connect(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, bookingId);
            ps.setInt(2, userId);
            ps.setString(3, now.toLocalDate().toString());
            ps.setString(4, now.toLocalDate().toString());
            ps.setString(5, now.toLocalTime().withNano(0).toString());
            return ps.executeUpdate() == 1;
        }
    }

    /** Admin approves or rejects a PENDING request. Returns false if it was no longer pending. */
    public static boolean decide(int bookingId, Booking.Status decision, String remarks) throws SQLException {
        String sql = "UPDATE bookings SET status = ?, admin_remarks = ? WHERE booking_id = ? AND status = 'PENDING'";
        try (Connection con = Db.connect(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, decision.name());
            ps.setString(2, remarks == null || remarks.isEmpty() ? null : remarks);
            ps.setInt(3, bookingId);
            return ps.executeUpdate() == 1;
        }
    }

    // ---------------------------------------------------------------------------------
    //  REPORT  - JOIN + GROUP BY + aggregate functions
    // ---------------------------------------------------------------------------------
    public static class UsageRow {
        public final String resourceName;
        public final String categoryName;
        public final int bookings;
        public final double hours;

        UsageRow(String resourceName, String categoryName, int bookings, double hours) {
            this.resourceName = resourceName;
            this.categoryName = categoryName;
            this.bookings = bookings;
            this.hours = hours;
        }
    }

    /** Approved bookings and booked hours for every resource (resources with no bookings show 0). */
    public static List<UsageRow> usageReport() throws SQLException {
        String sql = "SELECT r.name AS resource_name, c.name AS category_name, "
                   + "COUNT(b.booking_id) AS total_bookings, "
                   + "COALESCE(SUM(TIME_TO_SEC(TIMEDIFF(b.end_time, b.start_time))), 0) / 3600 AS hours "
                   + "FROM resources r "
                   + "JOIN categories c ON c.category_id = r.category_id "
                   + "LEFT JOIN bookings b ON b.resource_id = r.resource_id AND b.status = 'APPROVED' "
                   + "GROUP BY r.resource_id, r.name, c.name "
                   + "ORDER BY total_bookings DESC, r.name";
        List<UsageRow> rows = new ArrayList<>();
        try (Connection con = Db.connect();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                rows.add(new UsageRow(rs.getString("resource_name"), rs.getString("category_name"),
                        rs.getInt("total_bookings"), rs.getDouble("hours")));
            }
        }
        return rows;
    }
}
