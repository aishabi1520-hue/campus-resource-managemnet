package campus.web;

import campus.dao.BookingDao;
import campus.dao.ResourceDao;
import campus.dao.UserDao;
import campus.model.Booking;
import campus.model.Category;
import campus.model.Resource;
import campus.model.User;
import campus.util.Html;
import campus.web.Router.Access;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** The pages every logged-in user sees: dashboard and the resource catalogue. */
public class PortalController {

    public void register(Router r) {
        r.get("/dashboard", Access.USER, this::dashboard);
        r.get("/resources", Access.USER, this::resources);
    }

    // ------------------------------------------------------------------ dashboard
    private void dashboard(Ctx c) throws Exception {
        User u = c.user();
        LocalDateTime now = LocalDateTime.now();
        Map<Booking.Status, Integer> mine = BookingDao.statusCounts(u.getId());

        StringBuilder b = new StringBuilder();
        b.append("<h1>Hello, ").append(Html.esc(u.getFullName())).append("</h1>")
         .append("<p class=\"muted\">").append(u.getRole()).append(" &middot; ")
         .append(Html.esc(u.getDepartment() == null || u.getDepartment().isEmpty() ? "No department" : u.getDepartment()))
         .append("</p>");

        b.append("<div class=\"stats\">")
         .append(stat(ResourceDao.countActive(), "Bookable resources"))
         .append(stat(mine.get(Booking.Status.PENDING), "My pending requests"))
         .append(stat(mine.get(Booking.Status.APPROVED), "My approved bookings"));
        if (u.isAdmin()) {
            Map<Booking.Status, Integer> all = BookingDao.statusCounts(0);
            b.append(stat(all.get(Booking.Status.PENDING), "Awaiting approval (all users)"))
             .append(stat(UserDao.count(), "Registered users"));
        }
        b.append("</div>");

        // my next bookings
        b.append("<section class=\"card\"><div class=\"card-head\"><h2>My upcoming bookings</h2>")
         .append("<a class=\"btn btn-primary btn-small\" href=\"/resources\">Book a resource</a></div>");
        List<Booking> upcoming = new ArrayList<>();
        for (Booking bk : BookingDao.listByUser(u.getId())) {         // newest first ...
            if (bk.isUpcoming(now)) {
                upcoming.add(bk);
            }
        }
        Collections.reverse(upcoming);                                 // ... so flip: nearest first
        StringBuilder rows = new StringBuilder();
        for (int i = 0; i < Math.min(5, upcoming.size()); i++) {
            Booking bk = upcoming.get(i);
            rows.append("<tr><td>").append(Html.esc(bk.getResourceName())).append("</td><td>").append(Html.date(bk.getDate()))
                .append("</td><td>").append(Html.time(bk.getStartTime())).append(" &ndash; ").append(Html.time(bk.getEndTime()))
                .append("</td><td>").append(Html.badge(bk.getStatus().name())).append("</td></tr>");
        }
        if (upcoming.isEmpty()) {
            b.append("<p class=\"empty\">Nothing booked yet. Browse the resources and make your first booking.</p>");
        } else {
            b.append("<table class=\"table\"><thead><tr><th>Resource</th><th>Date</th><th>Time</th><th>Status</th></tr></thead><tbody>")
             .append(rows).append("</tbody></table>");
        }
        b.append("</section>");

        if (u.isAdmin()) {
            List<Booking> pending = BookingDao.listByStatus(Booking.Status.PENDING);
            b.append("<section class=\"card\"><div class=\"card-head\"><h2>Waiting for your decision</h2>")
             .append("<a class=\"btn btn-small\" href=\"/admin/bookings\">Open requests</a></div>");
            if (pending.isEmpty()) {
                b.append("<p class=\"empty\">No pending requests. You are all caught up.</p>");
            } else {
                b.append("<table class=\"table\"><thead><tr><th>Requested by</th><th>Resource</th><th>Date</th><th>Time</th></tr></thead><tbody>");
                for (int i = 0; i < Math.min(5, pending.size()); i++) {
                    Booking bk = pending.get(i);
                    b.append("<tr><td>").append(Html.esc(bk.getUserName())).append("</td><td>")
                     .append(Html.esc(bk.getResourceName())).append("</td><td>").append(Html.date(bk.getDate()))
                     .append("</td><td>").append(Html.time(bk.getStartTime())).append(" &ndash; ")
                     .append(Html.time(bk.getEndTime())).append("</td></tr>");
                }
                b.append("</tbody></table>");
            }
            b.append("</section>");
        }
        c.html("Dashboard", b.toString());
    }

    private static String stat(int number, String label) {
        return "<div class=\"stat\"><span class=\"num\">" + number + "</span><span class=\"lbl\">" + Html.esc(label) + "</span></div>";
    }

    // ------------------------------------------------------------------ resource catalogue
    private void resources(Ctx c) throws Exception {
        User u = c.user();
        int categoryId = c.num("category", 0);
        String text = c.str("q", "");

        Map<String, String> options = new LinkedHashMap<>();
        options.put("0", "All categories");
        for (Category cat : ResourceDao.categories()) {
            options.put(String.valueOf(cat.getId()), cat.getName());
        }
        List<Resource> list = ResourceDao.search(categoryId, text, !u.isAdmin());

        StringBuilder b = new StringBuilder();
        b.append("<h1>Campus resources</h1>")
         .append("<form method=\"get\" action=\"/resources\" class=\"filters\">")
         .append(Html.select("category", options, String.valueOf(categoryId)))
         .append("<input type=\"search\" name=\"q\" placeholder=\"Search by name or location\" value=\"").append(Html.esc(text)).append("\">")
         .append("<button class=\"btn\" type=\"submit\">Filter</button>");
        if (categoryId > 0 || !text.isEmpty()) {
            b.append("<a class=\"btn btn-light\" href=\"/resources\">Clear</a>");
        }
        b.append("</form>");

        if (list.isEmpty()) {
            b.append("<p class=\"empty card\">No resources match your search.</p>");
        } else {
            b.append("<p class=\"muted\">").append(list.size()).append(list.size() == 1 ? " resource found" : " resources found").append("</p>");
            b.append("<div class=\"grid\">");
            for (Resource res : list) {
                b.append("<article class=\"card res\"><div class=\"res-head\"><h3>").append(Html.esc(res.getName())).append("</h3>")
                 .append("<span class=\"tag\">").append(Html.esc(res.getCategoryName())).append("</span></div>")
                 .append("<p class=\"meta\">").append(Html.esc(res.getLocation())).append(" &middot; Capacity ").append(res.getCapacity()).append("</p>")
                 .append("<p>").append(Html.esc(res.getDescription())).append("</p>");
                if (res.isActive()) {
                    b.append("<a class=\"btn btn-primary\" href=\"/book?resource_id=").append(res.getId()).append("\">Book this resource</a>");
                } else {
                    b.append("<span class=\"badge badge-cancelled\">UNAVAILABLE</span>");
                }
                b.append("</article>");
            }
            b.append("</div>");
        }
        c.html("Resources", b.toString());
    }
}
