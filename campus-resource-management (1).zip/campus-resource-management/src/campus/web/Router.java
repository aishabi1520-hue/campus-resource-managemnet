package campus.web;

import campus.model.User;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/**
 * Front controller: every request enters here. It finds the route, attaches the session,
 * checks the CSRF token (POST) and the required role, then calls the controller method.
 */
public class Router implements HttpHandler {

    public enum Access { PUBLIC, USER, ADMIN }

    public interface Handler {
        void handle(Ctx c) throws Exception;
    }

    private static final class Route {
        final Access access;
        final Handler handler;

        Route(Access access, Handler handler) {
            this.access = access;
            this.handler = handler;
        }
    }

    private static final Path STATIC_DIR = Paths.get("web", "static").toAbsolutePath().normalize();
    private final Map<String, Route> routes = new HashMap<>();

    public void get(String path, Access access, Handler handler) {
        routes.put("GET " + path, new Route(access, handler));
    }

    public void post(String path, Access access, Handler handler) {
        routes.put("POST " + path, new Route(access, handler));
    }

    @Override
    public void handle(HttpExchange ex) throws IOException {
        Ctx c = null;
        try {
            c = new Ctx(ex);

            if (c.method.equals("GET") && c.path.startsWith("/static/")) {
                serveStatic(ex, c.path.substring("/static/".length()));
                return;
            }

            c.attachSession();
            Route route = routes.get(c.method + " " + c.path);
            if (route == null) {
                c.error(404, "The page you asked for does not exist.");
                return;
            }
            if (c.method.equals("POST") && !c.csrfValid()) {
                c.error(403, "Your security token is missing or has expired. Go back, reload the page and try again.");
                return;
            }
            if (route.access != Access.PUBLIC) {
                User u = c.user();
                if (u == null) {
                    c.flash("error", "Please log in to continue.");
                    c.redirect("/login");
                    return;
                }
                if (route.access == Access.ADMIN && !u.isAdmin()) {
                    c.error(403, "This page is for administrators only.");
                    return;
                }
            }
            route.handler.handle(c);

        } catch (Exception e) {
            e.printStackTrace();                            // full details go to the console only
            try {
                if (c != null) {
                    c.error(500, "Something went wrong on the server. Please try again.");
                }
            } catch (Exception ignored) {
                // response may already be partly sent
            }
        } finally {
            ex.close();
        }
    }

    private void serveStatic(HttpExchange ex, String name) throws IOException {
        Path file = STATIC_DIR.resolve(name).normalize();
        if (!file.startsWith(STATIC_DIR) || !Files.isRegularFile(file)) {   // blocks ../ path traversal
            ex.sendResponseHeaders(404, -1);
            return;
        }
        String type = name.endsWith(".css") ? "text/css; charset=utf-8"
                    : name.endsWith(".js") ? "application/javascript; charset=utf-8"
                    : "application/octet-stream";
        byte[] data = Files.readAllBytes(file);
        ex.getResponseHeaders().set("Content-Type", type);
        ex.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
        ex.getResponseHeaders().set("Cache-Control", "no-cache");
        ex.sendResponseHeaders(200, data.length);
        ex.getResponseBody().write(data);
    }
}
