package campus.web;

import campus.model.User;
import campus.util.Html;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

/** Everything a controller needs for one request: parameters, session, and ways to respond. */
public class Ctx {

    private static final int MAX_BODY = 64 * 1024;

    private final HttpExchange ex;
    public final String method;
    public final String path;
    private final Map<String, String> params = new HashMap<>();   // query string + form fields
    private Session session;
    private boolean sendCookie;

    public Ctx(HttpExchange ex) throws IOException {
        this.ex = ex;
        this.method = ex.getRequestMethod();
        this.path = ex.getRequestURI().getPath();
        parse(ex.getRequestURI().getRawQuery());
        if ("POST".equals(method)) {
            parse(new String(readBody(ex.getRequestBody()), StandardCharsets.UTF_8));
        }
    }

    // ---------------------------------------------------------------- parameters
    private void parse(String encoded) {
        if (encoded == null || encoded.isEmpty()) {
            return;
        }
        for (String pair : encoded.split("&")) {
            int eq = pair.indexOf('=');
            String key = eq < 0 ? pair : pair.substring(0, eq);
            String val = eq < 0 ? "" : pair.substring(eq + 1);
            params.put(URLDecoder.decode(key, StandardCharsets.UTF_8),
                       URLDecoder.decode(val, StandardCharsets.UTF_8));
        }
    }

    private static byte[] readBody(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
            if (out.size() > MAX_BODY) {
                throw new IOException("Request body too large");
            }
        }
        return out.toByteArray();
    }

    /** Trimmed parameter value, or the default if missing. */
    public String str(String name, String def) {
        String v = params.get(name);
        return v == null ? def : v.trim();
    }

    public int num(String name, int def) {
        try {
            return Integer.parseInt(str(name, ""));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    public boolean isChecked(String name) {
        return params.containsKey(name);
    }

    // ---------------------------------------------------------------- session
    void attachSession() {
        String sid = null;
        String header = ex.getRequestHeaders().getFirst("Cookie");
        if (header != null) {
            for (String part : header.split(";")) {
                String p = part.trim();
                if (p.startsWith("SID=")) {
                    sid = p.substring(4);
                }
            }
        }
        session = Sessions.find(sid);
        if (session == null) {
            session = Sessions.create();
            sendCookie = true;
        }
    }

    public Session session() {
        return session;
    }

    public User user() {
        return session == null ? null : session.user;
    }

    /** Called at login: throws the old session away and starts a fresh one (prevents session fixation). */
    public Session rotateSession() {
        Sessions.destroy(session);
        session = Sessions.create();
        sendCookie = true;
        return session;
    }

    public void logout() {
        Sessions.destroy(session);
        session = Sessions.create();
        sendCookie = true;
    }

    public void flash(String kind, String message) {
        session.flash(kind, message);
    }

    // ---------------------------------------------------------------- CSRF
    public String csrfField() {
        return "<input type=\"hidden\" name=\"_csrf\" value=\"" + Html.esc(session.csrfToken) + "\">";
    }

    boolean csrfValid() {
        String sent = params.get("_csrf");
        return sent != null && MessageDigest.isEqual(
                sent.getBytes(StandardCharsets.UTF_8), session.csrfToken.getBytes(StandardCharsets.UTF_8));
    }

    // ---------------------------------------------------------------- responses
    public void send(int status, String contentType, byte[] body) throws IOException {
        Headers h = ex.getResponseHeaders();
        h.set("Content-Type", contentType);
        h.set("X-Content-Type-Options", "nosniff");
        h.set("X-Frame-Options", "DENY");
        h.set("Content-Security-Policy", "default-src 'self'; frame-ancestors 'none'; form-action 'self'");
        if (contentType.startsWith("text/html")) {
            h.set("Cache-Control", "no-store");
        }
        if (sendCookie && session != null) {
            h.add("Set-Cookie", "SID=" + session.id + "; Path=/; HttpOnly; SameSite=Lax");
        }
        if (body.length == 0) {
            ex.sendResponseHeaders(status, -1);
        } else {
            ex.sendResponseHeaders(status, body.length);
            try (OutputStream os = ex.getResponseBody()) {
                os.write(body);
            }
        }
    }

    public void html(String title, String content) throws IOException {
        htmlStatus(200, title, content);
    }

    public void htmlStatus(int status, String title, String content) throws IOException {
        send(status, "text/html; charset=utf-8", Layout.render(this, title, content).getBytes(StandardCharsets.UTF_8));
    }

    /** 303 See Other: the browser then loads the target with GET (the Post/Redirect/Get pattern). */
    public void redirect(String location) throws IOException {
        ex.getResponseHeaders().set("Location", location);
        send(303, "text/plain", new byte[0]);
    }

    public void error(int status, String message) throws IOException {
        String title = status == 404 ? "Page not found" : status == 403 ? "Access denied" : "Error";
        htmlStatus(status, title, "<section class=\"card narrow\"><h1>" + Html.esc(title) + "</h1><p>"
                + Html.esc(message) + "</p><p><a class=\"btn\" href=\"/\">Back to home</a></p></section>");
    }
}
