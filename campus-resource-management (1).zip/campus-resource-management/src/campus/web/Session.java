package campus.web;

import campus.model.User;

import java.util.ArrayList;
import java.util.List;

/** Server-side session: who is logged in, the CSRF token and pending flash messages. */
public class Session {

    public final String id;
    public final String csrfToken;
    public volatile User user;                       // null = not logged in
    volatile long lastAccess = System.currentTimeMillis();
    private final List<String[]> flashes = new ArrayList<>();

    Session(String id, String csrfToken) {
        this.id = id;
        this.csrfToken = csrfToken;
    }

    void touch() {
        lastAccess = System.currentTimeMillis();
    }

    /** kind = "ok" or "error". Shown once on the next rendered page. */
    public synchronized void flash(String kind, String message) {
        flashes.add(new String[] { kind, message });
    }

    public synchronized List<String[]> takeFlashes() {
        List<String[]> copy = new ArrayList<>(flashes);
        flashes.clear();
        return copy;
    }
}
