package campus.web;

import java.security.SecureRandom;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** In-memory session store. Sessions expire after 30 minutes without activity. */
public final class Sessions {

    private static final long TIMEOUT_MS = 30L * 60 * 1000;
    private static final Map<String, Session> STORE = new ConcurrentHashMap<>();
    private static final SecureRandom RNG = new SecureRandom();

    private Sessions() { }

    public static Session create() {
        long now = System.currentTimeMillis();
        STORE.values().removeIf(s -> now - s.lastAccess > TIMEOUT_MS);      // clean up old sessions
        Session s = new Session(randomToken(), randomToken());
        STORE.put(s.id, s);
        return s;
    }

    public static Session find(String id) {
        if (id == null) {
            return null;
        }
        Session s = STORE.get(id);
        if (s == null) {
            return null;
        }
        if (System.currentTimeMillis() - s.lastAccess > TIMEOUT_MS) {
            STORE.remove(id);
            return null;
        }
        s.touch();
        return s;
    }

    public static void destroy(Session s) {
        if (s != null) {
            STORE.remove(s.id);
        }
    }

    private static String randomToken() {
        byte[] b = new byte[24];
        RNG.nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : b) {
            sb.append(String.format("%02x", x));
        }
        return sb.toString();
    }
}
