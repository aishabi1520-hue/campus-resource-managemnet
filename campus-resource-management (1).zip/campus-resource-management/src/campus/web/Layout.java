package campus.web;

import campus.dao.BookingDao;
import campus.model.Booking;
import campus.model.User;
import campus.util.Html;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/** Wraps page content in the common shell (web/templates/layout.html): top bar, menu, flash messages. */
public final class Layout {

    private static final String TEMPLATE_FILE = "web/templates/layout.html";

    private Layout() { }

    public static String render(Ctx c, String title, String content) throws IOException {
        String template = new String(Files.readAllBytes(Paths.get(TEMPLATE_FILE)), StandardCharsets.UTF_8);
        Map<String, String> vars = new HashMap<>();
        vars.put("title", Html.esc(title));
        vars.put("nav", nav(c));
        vars.put("user", userBox(c));
        vars.put("flash", flash(c));
        vars.put("content", content);
        return fill(template, vars);
    }

    /** Replaces {{name}} placeholders in a single pass, so inserted text is never re-scanned. */
    private static String fill(String template, Map<String, String> vars) {
        StringBuilder out = new StringBuilder(template.length() + 4096);
        int pos = 0;
        while (true) {
            int open = template.indexOf("{{", pos);
            int close = open < 0 ? -1 : template.indexOf("}}", open);
            if (open < 0 || close < 0) {
                out.append(template, pos, template.length());
                break;
            }
            out.append(template, pos, open);
            String value = vars.get(template.substring(open + 2, close).trim());
            out.append(value == null ? "" : value);
            pos = close + 2;
        }
        return out.toString();
    }

    private static String link(Ctx c, String href, String label) {
        boolean active = href.equals("/") ? c.path.equals("/") : c.path.startsWith(href);
        return "<a href=\"" + href + "\"" + (active ? " class=\"active\"" : "") + ">" + label + "</a>";
    }

    private static String nav(Ctx c) {
        User u = c.user();
        StringBuilder sb = new StringBuilder();
        if (u == null) {
            sb.append(link(c, "/login", "Login")).append(link(c, "/register", "Register"));
            return sb.toString();
        }
        sb.append(link(c, "/dashboard", "Dashboard"))
          .append(link(c, "/resources", "Resources"))
          .append(link(c, "/my-bookings", "My Bookings"));
        if (u.isAdmin()) {
            int pending = 0;
            try {
                pending = BookingDao.statusCounts(0).get(Booking.Status.PENDING);
            } catch (Exception ignored) {
                // the badge is optional; never break a page because of it
            }
            sb.append("<span class=\"nav-sep\"></span>")
              .append(link(c, "/admin/resources", "Manage Resources"))
              .append(link(c, "/admin/bookings", "Requests" + (pending > 0 ? " <span class=\"count\">" + pending + "</span>" : "")))
              .append(link(c, "/admin/reports", "Reports"))
              .append(link(c, "/admin/users", "Users"));
        }
        return sb.toString();
    }

    private static String userBox(Ctx c) {
        User u = c.user();
        if (u == null) {
            return "";
        }
        return "<span class=\"who\">" + Html.esc(u.getFullName()) + " <small>" + u.getRole() + "</small></span>"
             + "<form method=\"post\" action=\"/logout\" class=\"inline\">" + c.csrfField()
             + "<button type=\"submit\" class=\"btn btn-light btn-small\">Logout</button></form>";
    }

    private static String flash(Ctx c) {
        StringBuilder sb = new StringBuilder();
        for (String[] f : c.session().takeFlashes()) {
            sb.append("<div class=\"flash flash-").append(Html.esc(f[0])).append("\" role=\"status\">")
              .append(Html.esc(f[1])).append("</div>");
        }
        return sb.toString();
    }
}
