package campus.web;

import campus.dao.BookingDao;
import campus.dao.ResourceDao;
import campus.dao.UserDao;
import campus.model.Booking;
import campus.model.Category;
import campus.model.Resource;
import campus.model.User;
import campus.util.Html;
import campus.web.Router.Access;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Administrator pages: resource management, booking approvals, usage report, user list. */
public class AdminController {

    public void register(Router r) {
        r.get("/admin/resources", Access.ADMIN, this::resourceList);
        r.get("/admin/resources/edit", Access.ADMIN, this::resourceForm);
        r.post("/admin/resources/save", Access.ADMIN, this::resourceSave);
        r.post("/admin/resources/toggle", Access.ADMIN, this::resourceToggle);
        r.post("/admin/resources/delete", Access.ADMIN, this::resourceDelete);
        r.get("/admin/bookings", Access.ADMIN, this::bookingList);
        r.post("/admin/bookings/decide", Access.ADMIN, this::bookingDecide);
        r.get("/admin/reports", Access.ADMIN, this::reports);
        r.get("/admin/users", Access.ADMIN, this::users);
    }

    // =============================================================== resources
    private void resourceList(Ctx c) throws Exception {
        List<Resource> list = ResourceDao.search(0, "", false);
        StringBuilder b = new StringBuilder();
        b.append("<div class=\"card-head\"><h1>Manage resources</h1>")
         .append("<a class=\"btn btn-primary\" href=\"/admin/resources/edit\">+ Add resource</a></div>")
         .append("<section class=\"card\"><table class=\"table\"><thead><tr><th>Name</th><th>Category</th><th>Location</th>")
         .append("<th>Capacity</th><th>Status</th><th>Actions</th></tr></thead><tbody>");
        for (Resource r : list) {
            b.append("<tr><td><strong>").append(Html.esc(r.getName())).append("</strong></td><td>")
             .append(Html.esc(r.getCategoryName())).append("</td><td>").append(Html.esc(r.getLocation()))
             .append("</td><td>").append(r.getCapacity()).append("</td><td>")
             .append(r.isActive() ? "<span class=\"badge badge-approved\">ACTIVE</span>" : "<span class=\"badge badge-cancelled\">INACTIVE</span>")
             .append("</td><td class=\"actions\">")
             .append("<a class=\"btn btn-small\" href=\"/admin/resources/edit?id=").append(r.getId()).append("\">Edit</a>")
             .append(postButton(c, "/admin/resources/toggle", r.getId(), r.isActive() ? "Deactivate" : "Activate", "btn-light", null))
             .append(postButton(c, "/admin/resources/delete", r.getId(), "Delete", "btn-danger",
                     "Delete " + r.getName() + "? This cannot be undone."))
             .append("</td></tr>");
        }
        b.append("</tbody></table></section>");
        c.html("Manage resources", b.toString());
    }

    /** A small one-button POST form (with CSRF token) used for row actions. */
    private static String postButton(Ctx c, String action, int id, String label, String cssClass, String confirm) {
        return "<form method=\"post\" action=\"" + action + "\" class=\"inline\""
             + (confirm != null ? " data-confirm=\"" + Html.esc(confirm) + "\"" : "") + ">" + c.csrfField()
             + "<input type=\"hidden\" name=\"id\" value=\"" + id + "\">"
             + "<button class=\"btn btn-small " + cssClass + "\" type=\"submit\">" + Html.esc(label) + "</button></form>";
    }

    private void resourceForm(Ctx c) throws Exception {
        int id = c.num("id", 0);
        Resource existing = id > 0 ? ResourceDao.find(id) : null;
        if (id > 0 && existing == null) {
            c.error(404, "That resource does not exist.");
            return;
        }
        // values: from the request if the form was rejected, else from the database, else defaults
        String name = c.str("name", existing != null ? existing.getName() : "");
        String location = c.str("location", existing != null ? existing.getLocation() : "");
        String capacity = c.str("capacity", existing != null ? String.valueOf(existing.getCapacity()) : "1");
        String description = c.str("description", existing != null ? existing.getDescription() : "");
        String category = c.str("category", existing != null ? String.valueOf(existing.getCategoryId()) : "");
        boolean active = existing == null || existing.isActive();
        if (c.method.equals("POST")) {
            active = c.isChecked("active");
        }

        Map<String, String> cats = new LinkedHashMap<>();
        for (Category cat : ResourceDao.categories()) {
            cats.put(String.valueOf(cat.getId()), cat.getName());
        }

        StringBuilder b = new StringBuilder();
        b.append("<p><a href=\"/admin/resources\">&larr; All resources</a></p>")
         .append("<section class=\"card narrow\"><h1>").append(id > 0 ? "Edit resource" : "Add resource").append("</h1>")
         .append("<form method=\"post\" action=\"/admin/resources/save\" class=\"form\">").append(c.csrfField())
         .append("<input type=\"hidden\" name=\"id\" value=\"").append(id).append("\">")
         .append(Html.field("Name", "<input name=\"name\" required maxlength=\"100\" value=\"" + Html.esc(name) + "\">"))
         .append(Html.field("Category", Html.select("category", cats, category)))
         .append(Html.field("Location", "<input name=\"location\" required maxlength=\"120\" value=\"" + Html.esc(location) + "\">"))
         .append(Html.field("Capacity", "<input type=\"number\" name=\"capacity\" min=\"1\" max=\"5000\" required value=\"" + Html.esc(capacity) + "\">"))
         .append(Html.field("Description", "<textarea name=\"description\" rows=\"3\" maxlength=\"300\">" + Html.esc(description) + "</textarea>"))
         .append("<label class=\"check\"><input type=\"checkbox\" name=\"active\" value=\"1\"").append(active ? " checked" : "")
         .append("> Available for booking</label>")
         .append("<button class=\"btn btn-primary\" type=\"submit\">Save resource</button></form></section>");
        c.html(id > 0 ? "Edit resource" : "Add resource", b.toString());
    }

    private void resourceSave(Ctx c) throws Exception {
        int id = c.num("id", 0);
        String name = c.str("name", "");
        String location = c.str("location", "");
        String description = c.str("description", "");
        int categoryId = c.num("category", 0);
        int capacity = c.num("capacity", 0);
        boolean active = c.isChecked("active");

        String problem = null;
        if (name.isEmpty() || name.length() > 100) {
            problem = "Name is required (max 100 characters).";
        } else if (location.isEmpty()) {
            problem = "Location is required.";
        } else if (capacity < 1 || capacity > 5000) {
            problem = "Capacity must be a number between 1 and 5000.";
        } else if (categoryId < 1) {
            problem = "Please choose a category.";
        }
        if (problem != null) {
            c.flash("error", problem);
            resourceForm(c);
            return;
        }
        if (id > 0) {
            ResourceDao.update(id, name, categoryId, location, capacity, description, active);
            c.flash("ok", "Resource \"" + name + "\" updated.");
        } else {
            ResourceDao.insert(name, categoryId, location, capacity, description, active);
            c.flash("ok", "Resource \"" + name + "\" added.");
        }
        c.redirect("/admin/resources");
    }

    private void resourceToggle(Ctx c) throws Exception {
        Resource r = ResourceDao.find(c.num("id", 0));
        if (r != null) {
            ResourceDao.setActive(r.getId(), !r.isActive());
            c.flash("ok", "\"" + r.getName() + "\" is now " + (r.isActive() ? "inactive" : "active") + ".");
        }
        c.redirect("/admin/resources");
    }

    private void resourceDelete(Ctx c) throws Exception {
        Resource r = ResourceDao.find(c.num("id", 0));
        if (r != null) {
            try {
                ResourceDao.delete(r.getId());
                c.flash("ok", "\"" + r.getName() + "\" deleted.");
            } catch (SQLException e) {
                if ("23000".equals(e.getSQLState())) {            // foreign-key violation: bookings exist
                    c.flash("error", "\"" + r.getName() + "\" has booking history and cannot be deleted. Deactivate it instead.");
                } else {
                    throw e;
                }
            }
        }
        c.redirect("/admin/resources");
    }

    // =============================================================== booking requests
    private void bookingList(Ctx c) throws Exception {
        String filter = c.str("status", "PENDING").toUpperCase();
        Booking.Status status = null;
        try {
            status = Booking.Status.valueOf(filter);
        } catch (IllegalArgumentException e) {
            filter = "ALL";
        }
        List<Booking> list = BookingDao.listByStatus(status);

        StringBuilder b = new StringBuilder();
        b.append("<h1>Booking requests</h1><nav class=\"tabs\">");
        for (String f : new String[] { "PENDING", "APPROVED", "REJECTED", "CANCELLED", "ALL" }) {
            b.append("<a href=\"/admin/bookings?status=").append(f).append("\"")
             .append(f.equals(filter) ? " class=\"active\"" : "").append(">")
             .append(f.charAt(0)).append(f.substring(1).toLowerCase()).append("</a>");
        }
        b.append("</nav>");

        if (list.isEmpty()) {
            b.append("<p class=\"empty card\">No ").append(filter.equals("ALL") ? "" : filter.toLowerCase() + " ").append("bookings.</p>");
        } else {
            b.append("<section class=\"card\"><table class=\"table\"><thead><tr><th>#</th><th>Requested by</th><th>Resource</th>")
             .append("<th>Date &amp; time</th><th>Purpose</th><th>Status</th><th>Decision</th></tr></thead><tbody>");
            for (Booking bk : list) {
                b.append("<tr><td>").append(bk.getId()).append("</td><td>").append(Html.esc(bk.getUserName()))
                 .append("<div class=\"remark\">").append(Html.esc(bk.getUserEmail())).append("</div></td><td>")
                 .append(Html.esc(bk.getResourceName())).append("</td><td>").append(Html.date(bk.getDate()))
                 .append("<div class=\"remark\">").append(Html.time(bk.getStartTime())).append(" &ndash; ")
                 .append(Html.time(bk.getEndTime())).append("</div></td><td>").append(Html.esc(bk.getPurpose()))
                 .append("</td><td>").append(Html.badge(bk.getStatus().name()));
                if (bk.getAdminRemarks() != null) {
                    b.append("<div class=\"remark\">").append(Html.esc(bk.getAdminRemarks())).append("</div>");
                }
                b.append("</td><td>");
                if (bk.getStatus() == Booking.Status.PENDING) {
                    b.append("<form method=\"post\" action=\"/admin/bookings/decide\" class=\"decide\">").append(c.csrfField())
                     .append("<input type=\"hidden\" name=\"booking_id\" value=\"").append(bk.getId()).append("\">")
                     .append("<input type=\"hidden\" name=\"back\" value=\"").append(Html.esc(filter)).append("\">")
                     .append("<input name=\"remarks\" maxlength=\"200\" placeholder=\"Remarks (optional)\">")
                     .append("<button class=\"btn btn-ok btn-small\" name=\"decision\" value=\"APPROVED\" type=\"submit\">Approve</button>")
                     .append("<button class=\"btn btn-danger btn-small\" name=\"decision\" value=\"REJECTED\" type=\"submit\">Reject</button>")
                     .append("</form>");
                }
                b.append("</td></tr>");
            }
            b.append("</tbody></table></section>");
        }
        c.html("Booking requests", b.toString());
    }

    private void bookingDecide(Ctx c) throws Exception {
        Booking.Status decision;
        try {
            decision = Booking.Status.valueOf(c.str("decision", ""));
        } catch (IllegalArgumentException e) {
            decision = null;
        }
        if (decision != Booking.Status.APPROVED && decision != Booking.Status.REJECTED) {
            c.error(403, "Invalid decision.");
            return;
        }
        boolean done = BookingDao.decide(c.num("booking_id", 0), decision, c.str("remarks", ""));
        if (done) {
            c.flash("ok", "Booking #" + c.num("booking_id", 0) + " " + decision.name().toLowerCase() + ".");
        } else {
            c.flash("error", "That request was already handled.");
        }
        String back = c.str("back", "PENDING");
        c.redirect("/admin/bookings?status=" + (back.matches("[A-Z]+") ? back : "PENDING"));
    }

    // =============================================================== reports & users
    private void reports(Ctx c) throws Exception {
        Map<Booking.Status, Integer> counts = BookingDao.statusCounts(0);
        List<BookingDao.UsageRow> rows = BookingDao.usageReport();
        int max = 1;
        double totalHours = 0;
        int totalApproved = 0;
        for (BookingDao.UsageRow row : rows) {
            max = Math.max(max, row.bookings);
            totalHours += row.hours;
            totalApproved += row.bookings;
        }

        StringBuilder b = new StringBuilder();
        b.append("<h1>Usage report</h1><div class=\"stats\">");
        for (Booking.Status s : Booking.Status.values()) {
            b.append("<div class=\"stat\"><span class=\"num\">").append(counts.get(s)).append("</span><span class=\"lbl\">")
             .append(s.name().charAt(0)).append(s.name().substring(1).toLowerCase()).append(" bookings</span></div>");
        }
        b.append("<div class=\"stat\"><span class=\"num\">").append(String.format("%.1f", totalHours))
         .append("</span><span class=\"lbl\">Approved hours booked</span></div></div>");

        b.append("<section class=\"card\"><h2>Resource utilisation (approved bookings)</h2>")
         .append("<table class=\"table\"><thead><tr><th>Resource</th><th>Category</th><th>Bookings</th><th></th><th>Hours</th></tr></thead><tbody>");
        for (BookingDao.UsageRow row : rows) {
            b.append("<tr><td>").append(Html.esc(row.resourceName)).append("</td><td>").append(Html.esc(row.categoryName))
             .append("</td><td>").append(row.bookings).append("</td><td class=\"meter-cell\"><meter min=\"0\" max=\"")
             .append(max).append("\" value=\"").append(row.bookings).append("\"></meter></td><td>")
             .append(String.format("%.1f", row.hours)).append("</td></tr>");
        }
        b.append("</tbody></table><p class=\"muted\">Total approved bookings: ").append(totalApproved)
         .append(". Query: JOIN + LEFT JOIN + GROUP BY with COUNT and SUM.</p></section>");
        c.html("Reports", b.toString());
    }

    private void users(Ctx c) throws Exception {
        StringBuilder b = new StringBuilder();
        b.append("<h1>Registered users</h1><section class=\"card\"><table class=\"table\"><thead><tr>")
         .append("<th>Name</th><th>Email</th><th>Role</th><th>Department</th><th>Joined</th></tr></thead><tbody>");
        for (User u : UserDao.listAll()) {
            b.append("<tr><td>").append(Html.esc(u.getFullName())).append("</td><td>").append(Html.esc(u.getEmail()))
             .append("</td><td><span class=\"tag\">").append(u.getRole()).append("</span></td><td>")
             .append(Html.esc(u.getDepartment())).append("</td><td>").append(Html.esc(u.getCreatedAt())).append("</td></tr>");
        }
        b.append("</tbody></table></section>");
        c.html("Users", b.toString());
    }
}
