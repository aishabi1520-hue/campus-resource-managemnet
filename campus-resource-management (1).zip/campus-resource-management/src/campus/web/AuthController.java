package campus.web;

import campus.dao.UserDao;
import campus.model.User;
import campus.util.Html;
import campus.web.Router.Access;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;

/** Login, logout and self-registration. */
public class AuthController {

    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    public void register(Router r) {
        r.get("/", Access.PUBLIC, c -> c.redirect(c.user() != null ? "/dashboard" : "/login"));
        r.get("/login", Access.PUBLIC, this::loginForm);
        r.post("/login", Access.PUBLIC, this::login);
        r.post("/logout", Access.USER, this::logout);
        r.get("/register", Access.PUBLIC, this::registerForm);
        r.post("/register", Access.PUBLIC, this::registerSubmit);
    }

    // ------------------------------------------------------------------ login
    private void loginForm(Ctx c) throws Exception {
        if (c.user() != null) {
            c.redirect("/dashboard");
            return;
        }
        StringBuilder b = new StringBuilder();
        b.append("<div class=\"auth-grid\">");
        b.append("<section class=\"card\"><h1>Sign in</h1>")
         .append("<p class=\"muted\">Book classrooms, labs, halls and equipment across the campus.</p>")
         .append("<form method=\"post\" action=\"/login\" class=\"form\">").append(c.csrfField())
         .append(Html.field("Email", "<input type=\"email\" name=\"email\" required autofocus value=\""
                 + Html.esc(c.str("email", "")) + "\">"))
         .append(Html.field("Password", "<input type=\"password\" name=\"password\" required>"))
         .append("<button class=\"btn btn-primary\" type=\"submit\">Sign in</button>")
         .append("</form>")
         .append("<p class=\"muted\">New here? <a href=\"/register\">Create an account</a></p></section>");

        b.append("<aside class=\"card demo\"><h2>Demo accounts</h2>")
         .append("<p class=\"muted\">Created automatically on first start.</p>")
         .append("<table class=\"table compact\"><thead><tr><th>Role</th><th>Email</th><th>Password</th></tr></thead><tbody>")
         .append("<tr><td>Admin</td><td>admin@campus.edu</td><td>Admin@123</td></tr>")
         .append("<tr><td>Faculty</td><td>faculty@campus.edu</td><td>Faculty@123</td></tr>")
         .append("<tr><td>Student</td><td>student@campus.edu</td><td>Student@123</td></tr>")
         .append("</tbody></table></aside></div>");
        c.html("Sign in", b.toString());
    }

    private void login(Ctx c) throws Exception {
        String email = c.str("email", "").toLowerCase();
        String password = c.str("password", "");
        User user = UserDao.authenticate(email, password);
        if (user == null) {
            c.flash("error", "Invalid email or password.");
            loginForm(c);
            return;
        }
        Session fresh = c.rotateSession();               // new session id after login
        fresh.user = user;
        c.flash("ok", "Welcome, " + user.getFullName() + "!");
        c.redirect("/dashboard");
    }

    private void logout(Ctx c) throws Exception {
        c.logout();
        c.flash("ok", "You have been signed out.");
        c.redirect("/login");
    }

    // ------------------------------------------------------------------ register
    private void registerForm(Ctx c) throws Exception {
        if (c.user() != null) {
            c.redirect("/dashboard");
            return;
        }
        Map<String, String> roles = new LinkedHashMap<>();
        roles.put("STUDENT", "Student");
        roles.put("FACULTY", "Faculty");

        StringBuilder b = new StringBuilder();
        b.append("<section class=\"card narrow\"><h1>Create account</h1>")
         .append("<form method=\"post\" action=\"/register\" class=\"form\">").append(c.csrfField())
         .append(Html.field("Full name", "<input name=\"full_name\" required maxlength=\"100\" value=\""
                 + Html.esc(c.str("full_name", "")) + "\">"))
         .append(Html.field("Email", "<input type=\"email\" name=\"email\" required maxlength=\"120\" value=\""
                 + Html.esc(c.str("email", "")) + "\">"))
         .append(Html.field("Department", "<input name=\"department\" maxlength=\"80\" value=\""
                 + Html.esc(c.str("department", "")) + "\">"))
         .append(Html.field("I am a", Html.select("role", roles, c.str("role", "STUDENT"))))
         .append(Html.field("Password (min 6 characters)", "<input type=\"password\" name=\"password\" required minlength=\"6\">"))
         .append(Html.field("Confirm password", "<input type=\"password\" name=\"confirm\" required minlength=\"6\">"))
         .append("<button class=\"btn btn-primary\" type=\"submit\">Register</button>")
         .append("</form><p class=\"muted\">Already registered? <a href=\"/login\">Sign in</a></p></section>");
        c.html("Register", b.toString());
    }

    private void registerSubmit(Ctx c) throws Exception {
        String name = c.str("full_name", "");
        String email = c.str("email", "").toLowerCase();
        String dept = c.str("department", "");
        String password = c.str("password", "");
        User.Role role = "FACULTY".equals(c.str("role", "")) ? User.Role.FACULTY : User.Role.STUDENT;   // never ADMIN from the form

        String problem = null;
        if (name.length() < 2 || name.length() > 100) {
            problem = "Please enter your full name.";
        } else if (!EMAIL.matcher(email).matches()) {
            problem = "Please enter a valid email address.";
        } else if (password.length() < 6) {
            problem = "Password must be at least 6 characters.";
        } else if (!password.equals(c.str("confirm", ""))) {
            problem = "The two passwords do not match.";
        }
        if (problem == null) {
            try {
                if (UserDao.emailExists(email)) {
                    problem = "An account with this email already exists.";
                } else {
                    UserDao.create(name, email, password, role, dept);
                }
            } catch (SQLException e) {
                if ("23000".equals(e.getSQLState())) {               // duplicate key (two people registering at once)
                    problem = "An account with this email already exists.";
                } else {
                    throw e;
                }
            }
        }
        if (problem != null) {
            c.flash("error", problem);
            registerForm(c);
            return;
        }
        c.flash("ok", "Account created. You can sign in now.");
        c.redirect("/login");
    }
}
