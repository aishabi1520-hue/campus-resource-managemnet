package campus.web;

import campus.dao.BookingDao;
import campus.dao.ResourceDao;
import campus.model.Booking;
import campus.model.Resource;
import campus.model.User;
import campus.service.BookingException;
import campus.service.BookingService;
import campus.util.Html;
import campus.web.Router.Access;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/** Making a booking, listing my bookings, cancelling. */
public class BookingController {

    public void register(Router r) {
        r.get("/book", Access.USER, this::bookForm);
        r.post("/book", Access.USER, this::bookSubmit);
        r.get("/my-bookings", Access.USER, this::myBookings);
        r.post("/bookings/cancel", Access.USER, this::cancel);
    }

    // ------------------------------------------------------------------ booking form
    private void bookForm(Ctx c) throws Exception {
        Resource res = ResourceDao.find(c.num("resource_id", 0));
        if (res == null) {
            c.error(404, "That resource does not exist.");
            return;
        }
        renderForm(c, res);
    }

    /** Shows the form. Values come from the request, so after an error the user's input is kept. */
    private void renderForm(Ctx c, Resource res) throws IOException, SQLException {
        LocalDate today = LocalDate.now();
        String date = c.str("date", today.toString());
        String start = c.str("start", "09:00");
        String end = c.str("end", "10:00");

        StringBuilder b = new StringBuilder();
        b.append("<p><a href=\"/resources\">&larr; All resources</a></p>")
         .append("<div class=\"two-col\">");

        b.append("<section class=\"card\"><h1>Book ").append(Html.esc(res.getName())).append("</h1>")
         .append("<p class=\"meta\">").append(Html.esc(res.getCategoryName())).append(" &middot; ")
         .append(Html.esc(res.getLocation())).append(" &middot; Capacity ").append(res.getCapacity()).append("</p>");
        if (!res.isActive()) {
            b.append("<p class=\"flash flash-error\">This resource is currently unavailable for booking.</p></section>");
        } else {
            User u = c.user();
            if (u.getRole() == User.Role.STUDENT) {
                b.append("<p class=\"note\">Student requests are sent to the administrator for approval.</p>");
            } else {
                b.append("<p class=\"note\">As ").append(u.getRole().name().toLowerCase()).append(" your booking is approved instantly.</p>");
            }
            b.append("<form method=\"post\" action=\"/book\" class=\"form\">").append(c.csrfField())
             .append("<input type=\"hidden\" name=\"resource_id\" value=\"").append(res.getId()).append("\">")
             .append(Html.field("Date", "<input type=\"date\" name=\"date\" required min=\"" + today + "\" max=\""
                     + today.plusDays(BookingService.ADVANCE_DAYS) + "\" value=\"" + Html.esc(date) + "\">"))
             .append("<div class=\"row\">")
             .append(Html.field("Start time", "<input type=\"time\" name=\"start\" required min=\"08:00\" max=\"20:00\" step=\"900\" value=\"" + Html.esc(start) + "\">"))
             .append(Html.field("End time", "<input type=\"time\" name=\"end\" required min=\"08:00\" max=\"20:00\" step=\"900\" value=\"" + Html.esc(end) + "\">"))
             .append("</div>")
             .append(Html.field("Purpose", "<input name=\"purpose\" required minlength=\"3\" maxlength=\"200\" placeholder=\"e.g. Java lab practice session\" value=\""
                     + Html.esc(c.str("purpose", "")) + "\">"))
             .append("<button class=\"btn btn-primary\" type=\"submit\">Submit booking</button>")
             .append("</form><p class=\"muted\">Open 08:00 &ndash; 20:00 &middot; 30 minutes to 4 hours per booking &middot; up to ")
             .append(BookingService.ADVANCE_DAYS).append(" days ahead.</p></section>");
        }

        // schedule of this resource
        List<Booking> upcoming = BookingDao.upcomingForResource(res.getId(), today);
        b.append("<section class=\"card\"><h2>Already booked</h2>");
        if (upcoming.isEmpty()) {
            b.append("<p class=\"empty\">No upcoming bookings &ndash; every slot is free.</p>");
        } else {
            b.append("<table class=\"table compact\"><thead><tr><th>Date</th><th>Time</th><th>Status</th></tr></thead><tbody>");
            for (Booking bk : upcoming) {
                b.append("<tr><td>").append(Html.date(bk.getDate())).append("</td><td>")
                 .append(Html.time(bk.getStartTime())).append(" &ndash; ").append(Html.time(bk.getEndTime()))
                 .append("</td><td>").append(Html.badge(bk.getStatus().name())).append("</td></tr>");
            }
            b.append("</tbody></table>");
        }
        b.append("</section></div>");
        c.html("Book " + res.getName(), b.toString());
    }

    private void bookSubmit(Ctx c) throws Exception {
        Resource res = ResourceDao.find(c.num("resource_id", 0));
        if (res == null) {
            c.error(404, "That resource does not exist.");
            return;
        }
        try {
            Booking.Status status = BookingService.submit(c.user(), res.getId(), c.str("date", ""),
                    c.str("start", ""), c.str("end", ""), c.str("purpose", ""));
            c.flash("ok", status == Booking.Status.APPROVED
                    ? "Booking confirmed for " + res.getName() + "."
                    : "Request sent for " + res.getName() + ". You will see the decision under My Bookings.");
            c.redirect("/my-bookings");
        } catch (BookingException e) {
            c.flash("error", e.getMessage());
            renderForm(c, res);                          // stay on the form, keep the typed values
        }
    }

    // ------------------------------------------------------------------ my bookings
    private void myBookings(Ctx c) throws Exception {
        LocalDateTime now = LocalDateTime.now();
        List<Booking> list = BookingDao.listByUser(c.user().getId());

        StringBuilder b = new StringBuilder();
        b.append("<div class=\"card-head\"><h1>My bookings</h1>")
         .append("<a class=\"btn btn-primary\" href=\"/resources\">New booking</a></div>");
        if (list.isEmpty()) {
            b.append("<p class=\"empty card\">You have not made any bookings yet.</p>");
        } else {
            b.append("<section class=\"card\"><table class=\"table\"><thead><tr><th>#</th><th>Resource</th><th>Date</th><th>Time</th>")
             .append("<th>Purpose</th><th>Status</th><th></th></tr></thead><tbody>");
            for (Booking bk : list) {
                b.append("<tr><td>").append(bk.getId()).append("</td><td>").append(Html.esc(bk.getResourceName()))
                 .append("</td><td>").append(Html.date(bk.getDate()))
                 .append("</td><td>").append(Html.time(bk.getStartTime())).append(" &ndash; ").append(Html.time(bk.getEndTime()))
                 .append("</td><td>").append(Html.esc(bk.getPurpose()))
                 .append("</td><td>").append(Html.badge(bk.getStatus().name()));
                if (bk.getAdminRemarks() != null) {
                    b.append("<div class=\"remark\">").append(Html.esc(bk.getAdminRemarks())).append("</div>");
                }
                b.append("</td><td>");
                if (bk.isCancellable(now)) {
                    b.append("<form method=\"post\" action=\"/bookings/cancel\" class=\"inline\" data-confirm=\"Cancel this booking?\">")
                     .append(c.csrfField()).append("<input type=\"hidden\" name=\"booking_id\" value=\"").append(bk.getId()).append("\">")
                     .append("<button class=\"btn btn-danger btn-small\" type=\"submit\">Cancel</button></form>");
                }
                b.append("</td></tr>");
            }
            b.append("</tbody></table></section>");
        }
        c.html("My bookings", b.toString());
    }

    private void cancel(Ctx c) throws Exception {
        boolean done = BookingDao.cancel(c.num("booking_id", 0), c.user().getId(), LocalDateTime.now());
        if (done) {
            c.flash("ok", "Booking cancelled. The slot is free again.");
        } else {
            c.flash("error", "That booking could not be cancelled (it may have already started or changed).");
        }
        c.redirect("/my-bookings");
    }
}
