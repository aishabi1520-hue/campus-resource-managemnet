package campus.db;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * JDBC connection helper.
 * Reads config/db.properties once, loads the driver and hands out connections.
 * Every DAO method opens a connection with try-with-resources, so it is always closed.
 */
public final class Db {

    private static final Properties PROPS = new Properties();

    private Db() { }

    public static synchronized void load(String file) throws IOException {
        try (FileInputStream in = new FileInputStream(file)) {
            PROPS.load(in);
        }
        String driver = PROPS.getProperty("db.driver", "").trim();
        if (!driver.isEmpty()) {
            try {
                Class.forName(driver);                       // step 1 of JDBC: load the driver
            } catch (ClassNotFoundException e) {
                throw new IOException("JDBC driver '" + driver + "' not found. "
                        + "Copy the MySQL Connector/J jar into the lib/ folder.", e);
            }
        }
    }

    public static String setting(String key, String defaultValue) {
        return PROPS.getProperty(key, defaultValue).trim();
    }

    /** Step 2 of JDBC: open a connection using URL, user and password. */
    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(
                PROPS.getProperty("db.url"),
                PROPS.getProperty("db.user"),
                PROPS.getProperty("db.password"));
    }
}
